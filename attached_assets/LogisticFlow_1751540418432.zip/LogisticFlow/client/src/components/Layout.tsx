import { Link, useLocation } from "wouter";
import { Bell, Search, Truck, BarChart3, ClipboardList, Package, Route, Container, Calculator, Warehouse, FileText, TrendingUp, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

const navigation = [
  { name: "Дашборд", href: "/", icon: BarChart3 },
  { name: "Заказы", href: "/orders", icon: ClipboardList },
  { name: "Склад", href: "/inventory", icon: Package },
  { name: "Маршруты", href: "/routes", icon: Route },
  { name: "Доставка", href: "/shipments", icon: Container },
  { name: "Отслеживание", href: "/tracking", icon: MapPin },
  { name: "Аналитика", href: "/analytics", icon: TrendingUp },
  { name: "Уведомления", href: "/notifications", icon: Bell },
  { name: "Расчеты", href: "/costs", icon: Calculator },
  { name: "Операции склада", href: "/warehouse", icon: Warehouse },
  { name: "Счета", href: "/invoices", icon: FileText },
];

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const [location] = useLocation();

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <aside className="w-64 bg-white shadow-sm border-r border-gray-200 flex flex-col">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-primary rounded flex items-center justify-center">
              <Truck className="text-white w-4 h-4" />
            </div>
            <h1 className="text-xl font-semibold text-gray-900">LogisticsPro</h1>
          </div>
        </div>
        
        <nav className="flex-1 p-4">
          <ul className="space-y-2">
            {navigation.map((item) => {
              const isActive = location === item.href;
              const Icon = item.icon;
              
              return (
                <li key={item.name}>
                  <Link href={item.href}>
                    <div
                      className={cn(
                        "flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors cursor-pointer",
                        isActive
                          ? "bg-primary text-white"
                          : "text-gray-600 hover:bg-gray-100"
                      )}
                    >
                      <Icon className="w-5 h-5" />
                      <span>{item.name}</span>
                    </div>
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>
        
        <div className="p-4 border-t border-gray-200">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
              <span className="text-gray-600 text-sm font-medium">ИП</span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-gray-900">Иван Петров</p>
              <p className="text-xs text-gray-500">Логист</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 overflow-auto">
        {/* Top bar */}
        <header className="bg-white shadow-sm border-b border-gray-200 px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-semibold text-gray-900">
                {navigation.find(item => item.href === location)?.name || "Страница"}
              </h2>
              <p className="text-sm text-gray-600 mt-1">
                {location === "/" && "Обзор ключевых метрик логистики"}
                {location === "/orders" && "Управление заказами"}
                {location === "/inventory" && "Управление складскими запасами"}
                {location === "/routes" && "Планирование и оптимизация маршрутов"}
                {location === "/shipments" && "Отслеживание доставок"}
                {location === "/costs" && "Расчет стоимости услуг"}
                {location === "/warehouse" && "Складские операции"}
                {location === "/invoices" && "Управление счетами"}
              </p>
            </div>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  type="search"
                  placeholder="Поиск..."
                  className="pl-10 pr-4 py-2 w-64"
                />
              </div>
              <Button variant="ghost" size="icon" className="relative">
                <Bell className="w-5 h-5" />
                <span className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full"></span>
              </Button>
            </div>
          </div>
        </header>

        {/* Page content */}
        <div className="p-6">
          {children}
        </div>
      </main>
    </div>
  );
}
