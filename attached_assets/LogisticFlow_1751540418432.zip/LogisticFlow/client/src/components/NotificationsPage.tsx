import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Bell, CheckCircle, AlertTriangle, Info, Settings, Truck, Package, Clock, Mail } from "lucide-react";
import { cn, formatDate } from "@/lib/utils";
import { apiRequest } from "@/lib/queryClient";

interface Notification {
  id: number;
  type: 'info' | 'warning' | 'success' | 'error';
  title: string;
  message: string;
  timestamp: Date;
  read: boolean;
  category: 'order' | 'inventory' | 'delivery' | 'system';
}

// Mock notifications data - в реальном приложении это будет приходить с сервера
const mockNotifications: Notification[] = [
  {
    id: 1,
    type: 'warning',
    title: 'Низкий уровень запасов',
    message: 'Товар "Коробки картонные средние" заканчивается на складе (осталось 5 шт)',
    timestamp: new Date(Date.now() - 30 * 60 * 1000),
    read: false,
    category: 'inventory'
  },
  {
    id: 2,
    type: 'success',
    title: 'Заказ доставлен',
    message: 'Заказ #12345 успешно доставлен клиенту ООО "Стройматериалы"',
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
    read: false,
    category: 'delivery'
  },
  {
    id: 3,
    type: 'info',
    title: 'Новый заказ',
    message: 'Получен новый заказ #12348 от клиента ИП Иванов И.И.',
    timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000),
    read: true,
    category: 'order'
  },
  {
    id: 4,
    type: 'error',
    title: 'Задержка доставки',
    message: 'Маршрут "Центральный район" задерживается на 2 часа из-за пробок',
    timestamp: new Date(Date.now() - 6 * 60 * 60 * 1000),
    read: false,
    category: 'delivery'
  },
  {
    id: 5,
    type: 'info',
    title: 'Обновление системы',
    message: 'Запланировано техническое обслуживание системы 28 июня с 02:00 до 04:00',
    timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000),
    read: true,
    category: 'system'
  }
];

const notificationSettings = {
  orderAlerts: true,
  deliveryUpdates: true,
  inventoryWarnings: true,
  systemNotifications: false,
  emailNotifications: true,
  pushNotifications: true,
};

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState<Notification[]>(mockNotifications);
  const [settings, setSettings] = useState(notificationSettings);
  const queryClient = useQueryClient();

  const unreadCount = notifications.filter(n => !n.read).length;

  const markAsRead = (id: number) => {
    setNotifications(prev => 
      prev.map(n => n.id === id ? { ...n, read: true } : n)
    );
  };

  const markAllAsRead = () => {
    setNotifications(prev => 
      prev.map(n => ({ ...n, read: true }))
    );
  };

  const deleteNotification = (id: number) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const clearAll = () => {
    setNotifications([]);
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'success':
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'warning':
        return <AlertTriangle className="h-4 w-4 text-yellow-600" />;
      case 'error':
        return <AlertTriangle className="h-4 w-4 text-red-600" />;
      default:
        return <Info className="h-4 w-4 text-blue-600" />;
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'order':
        return <Package className="h-4 w-4" />;
      case 'delivery':
        return <Truck className="h-4 w-4" />;
      case 'inventory':
        return <Package className="h-4 w-4" />;
      case 'system':
        return <Settings className="h-4 w-4" />;
      default:
        return <Bell className="h-4 w-4" />;
    }
  };

  const filteredNotifications = (category?: string) => {
    if (!category) return notifications;
    return notifications.filter(n => n.category === category);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div className="flex items-center space-x-4">
          <h1 className="text-3xl font-bold">Уведомления</h1>
          {unreadCount > 0 && (
            <Badge variant="destructive" className="text-sm">
              {unreadCount} непрочитанных
            </Badge>
          )}
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" onClick={markAllAsRead} disabled={unreadCount === 0}>
            Отметить все как прочитанные
          </Button>
          <Button variant="outline" onClick={clearAll} disabled={notifications.length === 0}>
            Очистить все
          </Button>
        </div>
      </div>

      <Tabs defaultValue="all" className="space-y-4">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="all">
            Все ({notifications.length})
          </TabsTrigger>
          <TabsTrigger value="order">
            Заказы ({filteredNotifications('order').length})
          </TabsTrigger>
          <TabsTrigger value="delivery">
            Доставка ({filteredNotifications('delivery').length})
          </TabsTrigger>
          <TabsTrigger value="inventory">
            Склад ({filteredNotifications('inventory').length})
          </TabsTrigger>
          <TabsTrigger value="system">
            Система ({filteredNotifications('system').length})
          </TabsTrigger>
          <TabsTrigger value="settings">
            <Settings className="h-4 w-4" />
          </TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-4">
          <NotificationsList 
            notifications={notifications}
            onMarkAsRead={markAsRead}
            onDelete={deleteNotification}
          />
        </TabsContent>

        <TabsContent value="order" className="space-y-4">
          <NotificationsList 
            notifications={filteredNotifications('order')}
            onMarkAsRead={markAsRead}
            onDelete={deleteNotification}
          />
        </TabsContent>

        <TabsContent value="delivery" className="space-y-4">
          <NotificationsList 
            notifications={filteredNotifications('delivery')}
            onMarkAsRead={markAsRead}
            onDelete={deleteNotification}
          />
        </TabsContent>

        <TabsContent value="inventory" className="space-y-4">
          <NotificationsList 
            notifications={filteredNotifications('inventory')}
            onMarkAsRead={markAsRead}
            onDelete={deleteNotification}
          />
        </TabsContent>

        <TabsContent value="system" className="space-y-4">
          <NotificationsList 
            notifications={filteredNotifications('system')}
            onMarkAsRead={markAsRead}
            onDelete={deleteNotification}
          />
        </TabsContent>

        <TabsContent value="settings" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Настройки уведомлений</CardTitle>
              <CardDescription>
                Управляйте типами уведомлений, которые вы хотите получать
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Типы уведомлений</h3>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Package className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <p className="font-medium">Уведомления о заказах</p>
                      <p className="text-sm text-muted-foreground">Новые заказы, изменения статуса</p>
                    </div>
                  </div>
                  <Switch 
                    checked={settings.orderAlerts}
                    onCheckedChange={(checked) => 
                      setSettings(prev => ({ ...prev, orderAlerts: checked }))
                    }
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Truck className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <p className="font-medium">Обновления доставки</p>
                      <p className="text-sm text-muted-foreground">Статус доставки, задержки</p>
                    </div>
                  </div>
                  <Switch 
                    checked={settings.deliveryUpdates}
                    onCheckedChange={(checked) => 
                      setSettings(prev => ({ ...prev, deliveryUpdates: checked }))
                    }
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <AlertTriangle className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <p className="font-medium">Предупреждения о складе</p>
                      <p className="text-sm text-muted-foreground">Низкие остатки, критические уровни</p>
                    </div>
                  </div>
                  <Switch 
                    checked={settings.inventoryWarnings}
                    onCheckedChange={(checked) => 
                      setSettings(prev => ({ ...prev, inventoryWarnings: checked }))
                    }
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Settings className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <p className="font-medium">Системные уведомления</p>
                      <p className="text-sm text-muted-foreground">Обновления, техобслуживание</p>
                    </div>
                  </div>
                  <Switch 
                    checked={settings.systemNotifications}
                    onCheckedChange={(checked) => 
                      setSettings(prev => ({ ...prev, systemNotifications: checked }))
                    }
                  />
                </div>
              </div>

              <div className="space-y-4 border-t pt-4">
                <h3 className="text-lg font-medium">Способы доставки</h3>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Mail className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <p className="font-medium">Email уведомления</p>
                      <p className="text-sm text-muted-foreground">Получать уведомления на почту</p>
                    </div>
                  </div>
                  <Switch 
                    checked={settings.emailNotifications}
                    onCheckedChange={(checked) => 
                      setSettings(prev => ({ ...prev, emailNotifications: checked }))
                    }
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Bell className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <p className="font-medium">Push уведомления</p>
                      <p className="text-sm text-muted-foreground">Уведомления в браузере</p>
                    </div>
                  </div>
                  <Switch 
                    checked={settings.pushNotifications}
                    onCheckedChange={(checked) => 
                      setSettings(prev => ({ ...prev, pushNotifications: checked }))
                    }
                  />
                </div>
              </div>

              <Button className="w-full mt-6">
                Сохранить настройки
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

interface NotificationsListProps {
  notifications: Notification[];
  onMarkAsRead: (id: number) => void;
  onDelete: (id: number) => void;
}

function NotificationsList({ notifications, onMarkAsRead, onDelete }: NotificationsListProps) {
  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'success':
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'warning':
        return <AlertTriangle className="h-4 w-4 text-yellow-600" />;
      case 'error':
        return <AlertTriangle className="h-4 w-4 text-red-600" />;
      default:
        return <Info className="h-4 w-4 text-blue-600" />;
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'order':
        return <Package className="h-4 w-4" />;
      case 'delivery':
        return <Truck className="h-4 w-4" />;
      case 'inventory':
        return <Package className="h-4 w-4" />;
      case 'system':
        return <Settings className="h-4 w-4" />;
      default:
        return <Bell className="h-4 w-4" />;
    }
  };

  if (notifications.length === 0) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center justify-center py-12">
          <Bell className="h-12 w-12 text-muted-foreground mb-4" />
          <p className="text-lg font-medium text-muted-foreground">Нет уведомлений</p>
          <p className="text-sm text-muted-foreground">Все уведомления будут появляться здесь</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-2">
      {notifications.map((notification) => (
        <Card 
          key={notification.id} 
          className={cn(
            "transition-all hover:shadow-md",
            !notification.read && "bg-blue-50 border-blue-200"
          )}
        >
          <CardContent className="p-4">
            <div className="flex items-start space-x-4">
              <div className="flex items-center space-x-2 mt-1">
                {getNotificationIcon(notification.type)}
                {getCategoryIcon(notification.category)}
              </div>
              
              <div className="flex-1 space-y-1">
                <div className="flex items-center justify-between">
                  <h3 className={cn(
                    "font-medium",
                    !notification.read && "font-semibold"
                  )}>
                    {notification.title}
                  </h3>
                  {!notification.read && (
                    <div className="h-2 w-2 bg-blue-600 rounded-full" />
                  )}
                </div>
                
                <p className="text-sm text-muted-foreground">
                  {notification.message}
                </p>
                
                <div className="flex items-center justify-between mt-2">
                  <p className="text-xs text-muted-foreground">
                    {formatDate(notification.timestamp)}
                  </p>
                  
                  <div className="flex space-x-2">
                    {!notification.read && (
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => onMarkAsRead(notification.id)}
                      >
                        Отметить как прочитанное
                      </Button>
                    )}
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => onDelete(notification.id)}
                    >
                      Удалить
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}