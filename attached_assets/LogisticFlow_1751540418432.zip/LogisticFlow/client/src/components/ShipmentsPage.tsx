import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Plus, Search, Edit, Package, Truck, MapPin, Clock, CheckCircle, AlertCircle } from "lucide-react";
import { formatCurrency, formatDate, getStatusColor, getStatusText } from "@/lib/utils";
import { insertShipmentSchema, type Shipment } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";

const shipmentFormSchema = insertShipmentSchema.extend({
  trackingNumber: z.string().min(1, "Номер отслеживания обязателен"),
  orderId: z.number().min(1, "Выберите заказ"),
});

type ShipmentFormData = z.infer<typeof shipmentFormSchema>;

export default function ShipmentsPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isTrackDialogOpen, setIsTrackDialogOpen] = useState(false);
  const [selectedShipment, setSelectedShipment] = useState<Shipment | null>(null);
  const { toast } = useToast();

  const { data: shipments = [], isLoading } = useQuery<Shipment[]>({
    queryKey: ["/api/shipments"],
  });

  const { data: orders = [] } = useQuery({
    queryKey: ["/api/orders"],
  });

  const { data: routes = [] } = useQuery({
    queryKey: ["/api/routes"],
  });

  const createShipmentMutation = useMutation({
    mutationFn: async (data: ShipmentFormData) => {
      const response = await apiRequest("POST", "/api/shipments", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/shipments"] });
      setIsCreateDialogOpen(false);
      toast({
        title: "Успешно",
        description: "Отправка создана успешно",
      });
      form.reset();
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось создать отправку",
        variant: "destructive",
      });
    },
  });

  const updateShipmentMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<ShipmentFormData> }) => {
      const response = await apiRequest("PUT", `/api/shipments/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/shipments"] });
      toast({
        title: "Успешно",
        description: "Статус отправки обновлен",
      });
    },
  });

  const form = useForm<ShipmentFormData>({
    resolver: zodResolver(shipmentFormSchema),
    defaultValues: {
      trackingNumber: `TRACK-${Date.now().toString().slice(-8)}`,
      orderId: 0,
      status: "pending",
      currentLocation: "",
      notes: "",
    },
  });

  const availableOrders = orders.filter((order: any) => 
    order.status === "processing" || order.status === "in_transit"
  );

  const filteredShipments = shipments.filter(shipment => {
    const matchesSearch = shipment.trackingNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         (shipment.currentLocation && shipment.currentLocation.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesStatus = statusFilter === "all" || shipment.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const onSubmit = (data: ShipmentFormData) => {
    const shipmentData = {
      ...data,
      estimatedDelivery: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(), // +1 день
    };
    createShipmentMutation.mutate(shipmentData);
  };

  const updateStatus = (shipmentId: number, newStatus: string, location?: string) => {
    const updateData: any = { status: newStatus };
    if (location) updateData.currentLocation = location;
    if (newStatus === "delivered") updateData.actualDelivery = new Date().toISOString();
    
    updateShipmentMutation.mutate({ id: shipmentId, data: updateData });
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending": return AlertCircle;
      case "picked_up": return Package;
      case "in_transit": return Truck;
      case "out_for_delivery": return MapPin;
      case "delivered": return CheckCircle;
      default: return Package;
    }
  };

  if (isLoading) {
    return <div className="space-y-4">
      {[...Array(5)].map((_, i) => (
        <Card key={i} className="animate-pulse">
          <CardContent className="p-6">
            <div className="h-20 bg-gray-200 rounded"></div>
          </CardContent>
        </Card>
      ))}
    </div>;
  }

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Всего отправок</p>
                <p className="text-2xl font-bold">{shipments.length}</p>
              </div>
              <Package className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">В пути</p>
                <p className="text-2xl font-bold text-blue-600">
                  {shipments.filter(s => s.status === "in_transit").length}
                </p>
              </div>
              <Truck className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Доставляется</p>
                <p className="text-2xl font-bold text-orange-600">
                  {shipments.filter(s => s.status === "out_for_delivery").length}
                </p>
              </div>
              <MapPin className="w-8 h-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Доставлено</p>
                <p className="text-2xl font-bold text-green-600">
                  {shipments.filter(s => s.status === "delivered").length}
                </p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Ожидает</p>
                <p className="text-2xl font-bold text-yellow-600">
                  {shipments.filter(s => s.status === "pending").length}
                </p>
              </div>
              <Clock className="w-8 h-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Поиск отправок..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-64"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Фильтр по статусу" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Все статусы</SelectItem>
              <SelectItem value="pending">Ожидает</SelectItem>
              <SelectItem value="picked_up">Забрано</SelectItem>
              <SelectItem value="in_transit">В пути</SelectItem>
              <SelectItem value="out_for_delivery">Доставляется</SelectItem>
              <SelectItem value="delivered">Доставлено</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Создать отправку
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Создать новую отправку</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="trackingNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Номер отслеживания</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="orderId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Заказ</FormLabel>
                        <Select onValueChange={(value) => field.onChange(parseInt(value))}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Выберите заказ" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {availableOrders.map((order: any) => (
                              <SelectItem key={order.id} value={order.id.toString()}>
                                {order.orderNumber} - {order.customer}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="routeId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Маршрут (опционально)</FormLabel>
                        <Select onValueChange={(value) => field.onChange(value ? parseInt(value) : undefined)}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Выберите маршрут" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="">Без маршрута</SelectItem>
                            {routes.filter((route: any) => route.status === "active" || route.status === "planned").map((route: any) => (
                              <SelectItem key={route.id} value={route.id.toString()}>
                                {route.routeName} - {route.driverName}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="currentLocation"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Текущее местоположение</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="Склад, город, адрес" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Примечания</FormLabel>
                      <FormControl>
                        <Textarea {...field} placeholder="Дополнительная информация" rows={3} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex justify-end space-x-2">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setIsCreateDialogOpen(false)}
                  >
                    Отмена
                  </Button>
                  <Button type="submit" disabled={createShipmentMutation.isPending}>
                    {createShipmentMutation.isPending ? "Создание..." : "Создать отправку"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Shipments List */}
      <div className="space-y-4">
        {filteredShipments.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-gray-500">Отправки не найдены</p>
            </CardContent>
          </Card>
        ) : (
          filteredShipments.map((shipment) => {
            const StatusIcon = getStatusIcon(shipment.status);
            const relatedOrder = orders.find((order: any) => order.id === shipment.orderId);
            
            return (
              <Card key={shipment.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                        <StatusIcon className="w-6 h-6 text-primary" />
                      </div>
                      <div>
                        <div className="flex items-center space-x-2">
                          <h3 className="font-semibold text-lg">{shipment.trackingNumber}</h3>
                          <Badge className={getStatusColor(shipment.status)}>
                            {getStatusText(shipment.status)}
                          </Badge>
                        </div>
                        <p className="text-gray-600">
                          Заказ: {relatedOrder?.orderNumber || "—"}
                        </p>
                        <p className="text-sm text-gray-500">
                          {shipment.currentLocation && `Местоположение: ${shipment.currentLocation}`}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-4">
                      <div className="text-right">
                        <p className="text-sm text-gray-600">Создано</p>
                        <p className="font-medium">{formatDate(shipment.createdAt)}</p>
                        {shipment.estimatedDelivery && (
                          <>
                            <p className="text-sm text-gray-600 mt-1">Ожидается</p>
                            <p className="text-sm font-medium">{formatDate(shipment.estimatedDelivery)}</p>
                          </>
                        )}
                      </div>
                      
                      <div className="flex flex-col space-y-2">
                        {shipment.status === "pending" && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => updateStatus(shipment.id, "picked_up", "Склад отправления")}
                            disabled={updateShipmentMutation.isPending}
                          >
                            <Package className="w-4 h-4 mr-1" />
                            Забрано
                          </Button>
                        )}
                        
                        {shipment.status === "picked_up" && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => updateStatus(shipment.id, "in_transit", "В пути")}
                            disabled={updateShipmentMutation.isPending}
                          >
                            <Truck className="w-4 h-4 mr-1" />
                            В путь
                          </Button>
                        )}
                        
                        {shipment.status === "in_transit" && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => updateStatus(shipment.id, "out_for_delivery", "Курьер")}
                            disabled={updateShipmentMutation.isPending}
                          >
                            <MapPin className="w-4 h-4 mr-1" />
                            К доставке
                          </Button>
                        )}
                        
                        {shipment.status === "out_for_delivery" && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => updateStatus(shipment.id, "delivered", "Доставлено")}
                            disabled={updateShipmentMutation.isPending}
                          >
                            <CheckCircle className="w-4 h-4 mr-1" />
                            Доставлено
                          </Button>
                        )}

                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            setSelectedShipment(shipment);
                            setIsTrackDialogOpen(true);
                          }}
                        >
                          <Edit className="w-4 h-4 mr-1" />
                          Детали
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>

      {/* Tracking Details Dialog */}
      <Dialog open={isTrackDialogOpen} onOpenChange={setIsTrackDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Детали отслеживания</DialogTitle>
          </DialogHeader>
          {selectedShipment && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-600">Номер отслеживания</label>
                  <p className="font-semibold">{selectedShipment.trackingNumber}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-600">Статус</label>
                  <Badge className={getStatusColor(selectedShipment.status)}>
                    {getStatusText(selectedShipment.status)}
                  </Badge>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-600">Текущее местоположение</label>
                  <p>{selectedShipment.currentLocation || "—"}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-600">Создано</label>
                  <p>{formatDate(selectedShipment.createdAt)}</p>
                </div>
              </div>
              
              {selectedShipment.estimatedDelivery && (
                <div>
                  <label className="text-sm font-medium text-gray-600">Ожидаемая доставка</label>
                  <p>{formatDate(selectedShipment.estimatedDelivery)}</p>
                </div>
              )}
              
              {selectedShipment.actualDelivery && (
                <div>
                  <label className="text-sm font-medium text-gray-600">Фактическая доставка</label>
                  <p>{formatDate(selectedShipment.actualDelivery)}</p>
                </div>
              )}
              
              {selectedShipment.notes && (
                <div>
                  <label className="text-sm font-medium text-gray-600">Примечания</label>
                  <p>{selectedShipment.notes}</p>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
