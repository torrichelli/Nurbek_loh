import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Plus, Search, Edit, FileText, Download, Send, Eye, DollarSign, Clock, CheckCircle, AlertCircle } from "lucide-react";
import { formatCurrency, formatDate, getStatusColor, getStatusText } from "@/lib/utils";
import { insertInvoiceSchema, type Invoice } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";

const invoiceFormSchema = insertInvoiceSchema.extend({
  items: z.array(z.object({
    name: z.string().min(1, "Название обязательно"),
    quantity: z.number().min(1, "Количество должно быть больше 0"),
    price: z.string().min(1, "Цена обязательна"),
    total: z.string(),
  })).min(1, "Добавьте хотя бы один товар"),
  subtotal: z.string(),
  tax: z.string(),
  total: z.string(),
});

type InvoiceFormData = z.infer<typeof invoiceFormSchema>;

export default function InvoicesPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const { toast } = useToast();

  const { data: invoices = [], isLoading } = useQuery<Invoice[]>({
    queryKey: ["/api/invoices"],
  });

  const { data: orders = [] } = useQuery({
    queryKey: ["/api/orders"],
  });

  const createInvoiceMutation = useMutation({
    mutationFn: async (data: InvoiceFormData) => {
      const response = await apiRequest("POST", "/api/invoices", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
      setIsCreateDialogOpen(false);
      toast({
        title: "Успешно",
        description: "Счет создан успешно",
      });
      form.reset();
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось создать счет",
        variant: "destructive",
      });
    },
  });

  const updateInvoiceMutation = useMutation({
    mutationFn: async ({ id, status }: { id: number; status: string }) => {
      const response = await apiRequest("PUT", `/api/invoices/${id}`, { status });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
      toast({
        title: "Успешно",
        description: "Статус счета обновлен",
      });
    },
  });

  const form = useForm<InvoiceFormData>({
    resolver: zodResolver(invoiceFormSchema),
    defaultValues: {
      invoiceNumber: `INV-${new Date().getFullYear()}-${String(Date.now()).slice(-6)}`,
      customerName: "",
      customerAddress: "",
      items: [{ name: "", quantity: 1, price: "0", total: "0" }],
      subtotal: "0",
      tax: "0",
      total: "0",
      status: "draft",
      dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    },
  });

  const items = form.watch("items");

  const addItem = () => {
    form.setValue("items", [...items, { name: "", quantity: 1, price: "0", total: "0" }]);
  };

  const removeItem = (index: number) => {
    if (items.length > 1) {
      form.setValue("items", items.filter((_, i) => i !== index));
      updateTotals();
    }
  };

  const updateTotals = () => {
    const updatedItems = items.map(item => ({
      ...item,
      total: (item.quantity * parseFloat(item.price || "0")).toString()
    }));
    
    const subtotal = updatedItems.reduce((sum, item) => 
      sum + parseFloat(item.total || "0"), 0
    );
    
    const tax = subtotal * 0.2; // 20% НДС
    const total = subtotal + tax;
    
    form.setValue("items", updatedItems);
    form.setValue("subtotal", subtotal.toString());
    form.setValue("tax", tax.toString());
    form.setValue("total", total.toString());
  };

  const generateFromOrder = (orderId: string) => {
    const order = orders.find((o: any) => o.id === parseInt(orderId));
    if (order) {
      form.setValue("customerName", order.customer);
      form.setValue("customerAddress", order.deliveryAddress);
      form.setValue("orderId", order.id);
      
      if (Array.isArray(order.items)) {
        const invoiceItems = order.items.map((item: any) => ({
          name: item.name,
          quantity: item.quantity,
          price: item.price,
          total: (item.quantity * parseFloat(item.price)).toString()
        }));
        form.setValue("items", invoiceItems);
        updateTotals();
      }
    }
  };

  const filteredInvoices = invoices.filter(invoice => {
    const matchesSearch = invoice.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         invoice.invoiceNumber.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "all" || invoice.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const onSubmit = (data: InvoiceFormData) => {
    createInvoiceMutation.mutate(data);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "draft": return FileText;
      case "sent": return Send;
      case "paid": return CheckCircle;
      case "overdue": return AlertCircle;
      default: return FileText;
    }
  };

  const totalInvoiceValue = invoices.reduce((sum, invoice) => 
    sum + parseFloat(invoice.total), 0
  );

  const paidInvoices = invoices.filter(inv => inv.status === "paid");
  const overdueInvoices = invoices.filter(inv => inv.status === "overdue");

  if (isLoading) {
    return <div className="space-y-4">
      {[...Array(5)].map((_, i) => (
        <Card key={i} className="animate-pulse">
          <CardContent className="p-6">
            <div className="h-20 bg-gray-200 rounded"></div>
          </CardContent>
        </Card>
      ))}
    </div>;
  }

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Общая сумма</p>
                <p className="text-2xl font-bold">{formatCurrency(totalInvoiceValue)}</p>
              </div>
              <DollarSign className="w-8 h-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Оплачено</p>
                <p className="text-2xl font-bold text-green-600">{paidInvoices.length}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Просрочено</p>
                <p className="text-2xl font-bold text-red-600">{overdueInvoices.length}</p>
              </div>
              <AlertCircle className="w-8 h-8 text-red-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Всего счетов</p>
                <p className="text-2xl font-bold">{invoices.length}</p>
              </div>
              <FileText className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Поиск счетов..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-64"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Фильтр по статусу" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Все статусы</SelectItem>
              <SelectItem value="draft">Черновик</SelectItem>
              <SelectItem value="sent">Отправлен</SelectItem>
              <SelectItem value="paid">Оплачен</SelectItem>
              <SelectItem value="overdue">Просрочен</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Создать счет
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Создать новый счет</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="flex justify-between items-center">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 flex-1">
                    <FormField
                      control={form.control}
                      name="invoiceNumber"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Номер счета</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="dueDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Срок оплаты</FormLabel>
                          <FormControl>
                            <Input {...field} type="date" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <div className="ml-4">
                    <label className="text-sm font-medium text-gray-600">Создать из заказа</label>
                    <Select onValueChange={generateFromOrder}>
                      <SelectTrigger className="w-48">
                        <SelectValue placeholder="Выберите заказ" />
                      </SelectTrigger>
                      <SelectContent>
                        {orders.filter((order: any) => order.status === "delivered").map((order: any) => (
                          <SelectItem key={order.id} value={order.id.toString()}>
                            {order.orderNumber}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="customerName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Клиент</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="Название компании" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div></div>
                </div>

                <FormField
                  control={form.control}
                  name="customerAddress"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Адрес клиента</FormLabel>
                      <FormControl>
                        <Textarea {...field} placeholder="Полный адрес клиента" rows={2} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Items */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <label className="text-sm font-medium">Товары и услуги</label>
                    <Button type="button" variant="outline" size="sm" onClick={addItem}>
                      <Plus className="w-4 h-4 mr-1" />
                      Добавить строку
                    </Button>
                  </div>
                  
                  {items.map((_, index) => (
                    <div key={index} className="grid grid-cols-1 md:grid-cols-5 gap-2 p-4 border rounded-lg">
                      <FormField
                        control={form.control}
                        name={`items.${index}.name`}
                        render={({ field }) => (
                          <FormItem>
                            <FormControl>
                              <Input {...field} placeholder="Название товара/услуги" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name={`items.${index}.quantity`}
                        render={({ field }) => (
                          <FormItem>
                            <FormControl>
                              <Input 
                                {...field} 
                                type="number" 
                                placeholder="Кол-во"
                                onChange={(e) => {
                                  field.onChange(parseInt(e.target.value) || 1);
                                  setTimeout(updateTotals, 0);
                                }}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name={`items.${index}.price`}
                        render={({ field }) => (
                          <FormItem>
                            <FormControl>
                              <Input 
                                {...field} 
                                placeholder="Цена"
                                onChange={(e) => {
                                  field.onChange(e.target.value);
                                  setTimeout(updateTotals, 0);
                                }}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <div className="flex items-center">
                        <span className="text-sm font-medium">
                          {formatCurrency(items[index].quantity * parseFloat(items[index].price || "0"))}
                        </span>
                      </div>
                      <Button 
                        type="button" 
                        variant="outline" 
                        size="sm" 
                        onClick={() => removeItem(index)}
                        disabled={items.length === 1}
                      >
                        ×
                      </Button>
                    </div>
                  ))}
                </div>

                <div className="border-t pt-4">
                  <div className="space-y-2 text-right">
                    <div className="flex justify-between">
                      <span>Подытог:</span>
                      <span className="font-medium">{formatCurrency(form.watch("subtotal"))}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>НДС (20%):</span>
                      <span className="font-medium">{formatCurrency(form.watch("tax"))}</span>
                    </div>
                    <div className="flex justify-between text-lg font-bold">
                      <span>Итого:</span>
                      <span className="text-primary">{formatCurrency(form.watch("total"))}</span>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end space-x-2">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setIsCreateDialogOpen(false)}
                  >
                    Отмена
                  </Button>
                  <Button type="submit" disabled={createInvoiceMutation.isPending}>
                    {createInvoiceMutation.isPending ? "Создание..." : "Создать счет"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Invoices List */}
      <div className="space-y-4">
        {filteredInvoices.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-gray-500">Счета не найдены</p>
            </CardContent>
          </Card>
        ) : (
          filteredInvoices.map((invoice) => {
            const StatusIcon = getStatusIcon(invoice.status);
            
            return (
              <Card key={invoice.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                        <StatusIcon className="w-6 h-6 text-primary" />
                      </div>
                      <div>
                        <div className="flex items-center space-x-2">
                          <h3 className="font-semibold text-lg">{invoice.invoiceNumber}</h3>
                          <Badge className={getStatusColor(invoice.status)}>
                            {getStatusText(invoice.status)}
                          </Badge>
                        </div>
                        <p className="text-gray-600">{invoice.customerName}</p>
                        <p className="text-sm text-gray-500">
                          Создан: {formatDate(invoice.createdAt)}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-4">
                      <div className="text-right">
                        <p className="text-xl font-bold">{formatCurrency(invoice.total)}</p>
                        {invoice.dueDate && (
                          <p className="text-sm text-gray-500">
                            Срок: {formatDate(invoice.dueDate)}
                          </p>
                        )}
                      </div>
                      
                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setSelectedInvoice(invoice);
                            setIsViewDialogOpen(true);
                          }}
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                        
                        <Button
                          variant="outline"
                          size="sm"
                        >
                          <Download className="w-4 h-4" />
                        </Button>
                        
                        {invoice.status === "draft" && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => updateInvoiceMutation.mutate({ id: invoice.id, status: "sent" })}
                            disabled={updateInvoiceMutation.isPending}
                          >
                            <Send className="w-4 h-4 mr-1" />
                            Отправить
                          </Button>
                        )}
                        
                        {invoice.status === "sent" && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => updateInvoiceMutation.mutate({ id: invoice.id, status: "paid" })}
                            disabled={updateInvoiceMutation.isPending}
                          >
                            <CheckCircle className="w-4 h-4 mr-1" />
                            Оплачен
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>

      {/* View Invoice Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Просмотр счета</DialogTitle>
          </DialogHeader>
          {selectedInvoice && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="font-semibold text-lg">{selectedInvoice.invoiceNumber}</h3>
                  <p className="text-gray-600">Дата: {formatDate(selectedInvoice.createdAt)}</p>
                  {selectedInvoice.dueDate && (
                    <p className="text-gray-600">Срок оплаты: {formatDate(selectedInvoice.dueDate)}</p>
                  )}
                </div>
                <div className="text-right">
                  <Badge className={getStatusColor(selectedInvoice.status)}>
                    {getStatusText(selectedInvoice.status)}
                  </Badge>
                </div>
              </div>
              
              <div>
                <h4 className="font-medium text-gray-900">Клиент:</h4>
                <p>{selectedInvoice.customerName}</p>
                <p className="text-sm text-gray-600">{selectedInvoice.customerAddress}</p>
              </div>
              
              <div>
                <h4 className="font-medium text-gray-900 mb-2">Товары и услуги:</h4>
                <div className="space-y-2">
                  {Array.isArray(selectedInvoice.items) && selectedInvoice.items.map((item: any, index: number) => (
                    <div key={index} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                      <div>
                        <span className="font-medium">{item.name}</span>
                        <span className="text-gray-600 ml-2">× {item.quantity}</span>
                      </div>
                      <span>{formatCurrency(item.total || (item.quantity * parseFloat(item.price)))}</span>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="border-t pt-4">
                <div className="space-y-2 text-right">
                  <div className="flex justify-between">
                    <span>Подытог:</span>
                    <span className="font-medium">{formatCurrency(selectedInvoice.subtotal)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>НДС:</span>
                    <span className="font-medium">{formatCurrency(selectedInvoice.tax || "0")}</span>
                  </div>
                  <div className="flex justify-between text-lg font-bold">
                    <span>Итого:</span>
                    <span className="text-primary">{formatCurrency(selectedInvoice.total)}</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
