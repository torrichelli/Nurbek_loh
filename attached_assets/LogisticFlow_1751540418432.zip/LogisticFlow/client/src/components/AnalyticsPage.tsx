import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from "recharts";
import { TrendingUp, TrendingDown, Package, Truck, Clock, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";

const COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff7300', '#00ff88'];

export default function AnalyticsPage() {
  const { data: metrics } = useQuery({
    queryKey: ['/api/dashboard/metrics'],
  });

  const { data: orders } = useQuery({
    queryKey: ['/api/orders'],
  });

  const { data: inventory } = useQuery({
    queryKey: ['/api/inventory'],
  });

  const { data: shipments } = useQuery({
    queryKey: ['/api/shipments'],
  });

  const { data: routes } = useQuery({
    queryKey: ['/api/routes'],
  });

  // Generate sample analytics data
  const orderTrends = [
    { month: 'Янв', orders: 45, revenue: 12000 },
    { month: 'Фев', orders: 52, revenue: 15000 },
    { month: 'Мар', orders: 48, revenue: 13500 },
    { month: 'Апр', orders: 61, revenue: 18000 },
    { month: 'Май', orders: 55, revenue: 16500 },
    { month: 'Июн', orders: 67, revenue: 21000 },
  ];

  const statusDistribution = [
    { name: 'Доставлено', value: 45, color: '#10b981' },
    { name: 'В пути', value: 30, color: '#3b82f6' },
    { name: 'Ожидает', value: 20, color: '#f59e0b' },
    { name: 'Отменено', value: 5, color: '#ef4444' },
  ];

  const inventoryStats = inventory?.map(item => ({
    name: item.itemName,
    stock: item.quantity,
    minStock: item.minQuantity,
    category: item.category || 'Общее',
  })) || [];

  const lowStockItems = inventoryStats.filter(item => item.stock <= item.minStock);
  const stockFillRate = inventoryStats.map(item => ({
    name: item.name,
    fillRate: Math.min((item.stock / item.minStock) * 100, 100),
  }));

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Аналитика и отчеты</h1>
        <Badge variant="outline" className="text-sm">
          Обновлено: {new Date().toLocaleString('ru-RU')}
        </Badge>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Обзор</TabsTrigger>
          <TabsTrigger value="orders">Заказы</TabsTrigger>
          <TabsTrigger value="inventory">Склад</TabsTrigger>
          <TabsTrigger value="performance">Производительность</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Активные заказы</CardTitle>
                <Package className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{metrics?.activeOrders || 0}</div>
                <p className="text-xs text-muted-foreground">
                  <span className={cn(
                    "inline-flex items-center",
                    metrics?.activeOrdersChange?.startsWith('+') ? "text-green-600" : "text-red-600"
                  )}>
                    {metrics?.activeOrdersChange?.startsWith('+') ? <TrendingUp className="h-3 w-3 mr-1" /> : <TrendingDown className="h-3 w-3 mr-1" />}
                    {metrics?.activeOrdersChange} за месяц
                  </span>
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">В транзите</CardTitle>
                <Truck className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{metrics?.inTransit || 0}</div>
                <p className="text-xs text-muted-foreground">
                  <span className="text-blue-600">
                    {metrics?.inTransitChange} активных маршрутов
                  </span>
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Доставлено сегодня</CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{metrics?.deliveredToday || 0}</div>
                <p className="text-xs text-muted-foreground">
                  <span className="text-green-600">
                    {metrics?.deliveredChange} выполнение цели
                  </span>
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Проблемы</CardTitle>
                <AlertTriangle className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{metrics?.issues || 0}</div>
                <p className="text-xs text-muted-foreground">
                  <span className="text-red-600">
                    {lowStockItems.length} товаров с низким остатком
                  </span>
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Тренд заказов</CardTitle>
                <CardDescription>Количество заказов и выручка по месяцам</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={orderTrends}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="orders" fill="#3b82f6" name="Заказы" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Статусы доставок</CardTitle>
                <CardDescription>Распределение по статусам</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={statusDistribution}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {statusDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="orders" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Динамика заказов</CardTitle>
              <CardDescription>Изменение количества заказов и выручки</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <LineChart data={orderTrends}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis yAxisId="left" />
                  <YAxis yAxisId="right" orientation="right" />
                  <Tooltip />
                  <Line yAxisId="left" type="monotone" dataKey="orders" stroke="#3b82f6" name="Заказы" />
                  <Line yAxisId="right" type="monotone" dataKey="revenue" stroke="#10b981" name="Выручка (руб)" />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="inventory" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Критические остатки</CardTitle>
                <CardDescription>Товары с низким уровнем запасов</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {lowStockItems.slice(0, 5).map((item, index) => (
                    <div key={index} className="flex items-center space-x-4">
                      <div className="flex-1">
                        <p className="text-sm font-medium">{item.name}</p>
                        <p className="text-xs text-muted-foreground">{item.category}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium">{item.stock} шт</p>
                        <p className="text-xs text-red-600">Мин: {item.minStock}</p>
                      </div>
                    </div>
                  ))}
                  {lowStockItems.length === 0 && (
                    <p className="text-center text-muted-foreground py-4">
                      Все товары в достаточном количестве
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Заполненность склада</CardTitle>
                <CardDescription>Процент заполнения по товарам</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {stockFillRate.slice(0, 8).map((item, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>{item.name}</span>
                        <span>{item.fillRate.toFixed(0)}%</span>
                      </div>
                      <Progress 
                        value={item.fillRate} 
                        className={cn(
                          "h-2",
                          item.fillRate < 50 ? "bg-red-100" : 
                          item.fillRate < 80 ? "bg-yellow-100" : "bg-green-100"
                        )}
                      />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="performance" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Эффективность доставки</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-green-600">94.2%</div>
                <p className="text-sm text-muted-foreground">Доставка в срок</p>
                <Progress value={94.2} className="mt-2" />
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Среднее время доставки</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-blue-600">2.3</div>
                <p className="text-sm text-muted-foreground">дня в среднем</p>
                <p className="text-xs text-green-600 mt-1">-0.4 дня к прошлому месяцу</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Оборачиваемость склада</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-purple-600">12.5</div>
                <p className="text-sm text-muted-foreground">раз в год</p>
                <p className="text-xs text-green-600 mt-1">+1.2 к прошлому году</p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}