import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, MapPin, Clock, Truck, Package, CheckCircle, AlertCircle } from "lucide-react";
import { cn, formatDate, getStatusColor } from "@/lib/utils";

export default function TrackingPage() {
  const [trackingNumber, setTrackingNumber] = useState("");
  const [searchedNumber, setSearchedNumber] = useState("");

  const { data: shipments } = useQuery({
    queryKey: ['/api/shipments'],
  });

  const { data: routes } = useQuery({
    queryKey: ['/api/routes'],
  });

  const handleSearch = () => {
    if (trackingNumber.trim()) {
      setSearchedNumber(trackingNumber.trim());
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  // Найти отправление по трек-номеру
  const trackedShipment = shipments?.find(s => 
    s.trackingNumber === searchedNumber
  );

  // Найти маршрут для отправления
  const shipmentRoute = trackedShipment && routes?.find(r => 
    r.id === trackedShipment.routeId
  );

  // Симуляция истории отслеживания
  const getTrackingHistory = (shipment: any) => {
    if (!shipment) return [];
    
    const history = [
      {
        status: "Заказ создан",
        timestamp: new Date(shipment.createdAt),
        location: "Центральный склад",
        description: "Заказ принят в обработку"
      },
      {
        status: "Собран на складе",
        timestamp: new Date(shipment.createdAt.getTime() + 2 * 60 * 60 * 1000),
        location: "Центральный склад",
        description: "Товары собраны и упакованы"
      }
    ];

    if (shipment.status !== "pending") {
      history.push({
        status: "Передан в доставку",
        timestamp: new Date(shipment.createdAt.getTime() + 4 * 60 * 60 * 1000),
        location: "Транспортный узел",
        description: "Отправление передано курьерской службе"
      });
    }

    if (shipment.status === "in_transit" || shipment.status === "delivered") {
      history.push({
        status: "В пути",
        timestamp: new Date(shipment.createdAt.getTime() + 6 * 60 * 60 * 1000),
        location: shipment.currentLocation || "В пути",
        description: "Отправление находится в пути к получателю"
      });
    }

    if (shipment.status === "delivered") {
      history.push({
        status: "Доставлено",
        timestamp: shipment.actualDelivery || new Date(),
        location: "Адрес получателя",
        description: "Отправление успешно доставлено получателю"
      });
    }

    return history.reverse();
  };

  // Активные отправления для карты в реальном времени  
  const activeShipments = shipments?.filter(s => 
    s.status === "in_transit" || s.status === "pending"
  ) || [];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Отслеживание отправлений</h1>
        <Badge variant="outline" className="text-sm">
          {activeShipments.length} активных отправлений
        </Badge>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Search className="h-5 w-5" />
            <span>Отследить отправление</span>
          </CardTitle>
          <CardDescription>
            Введите трек-номер для получения актуальной информации о доставке
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex space-x-2">
            <Input
              placeholder="Введите трек-номер (например: TRK001)"
              value={trackingNumber}
              onChange={(e) => setTrackingNumber(e.target.value)}
              onKeyPress={handleKeyPress}
              className="flex-1"
            />
            <Button onClick={handleSearch} disabled={!trackingNumber.trim()}>
              <Search className="h-4 w-4 mr-2" />
              Отследить
            </Button>
          </div>
        </CardContent>
      </Card>

      {searchedNumber && (
        <Card>
          <CardHeader>
            <CardTitle>Результаты поиска</CardTitle>
            <CardDescription>Трек-номер: {searchedNumber}</CardDescription>
          </CardHeader>
          <CardContent>
            {trackedShipment ? (
              <div className="space-y-6">
                {/* Основная информация */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="flex items-center space-x-3">
                    <Package className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <p className="text-sm font-medium">Статус</p>
                      <Badge className={getStatusColor(trackedShipment.status)}>
                        {trackedShipment.status === "pending" ? "Ожидает" :
                         trackedShipment.status === "in_transit" ? "В пути" :
                         trackedShipment.status === "delivered" ? "Доставлено" : trackedShipment.status}
                      </Badge>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3">
                    <MapPin className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <p className="text-sm font-medium">Текущее местоположение</p>
                      <p className="text-sm text-muted-foreground">
                        {trackedShipment.currentLocation || "Не указано"}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3">
                    <Clock className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <p className="text-sm font-medium">Ожидаемая доставка</p>
                      <p className="text-sm text-muted-foreground">
                        {trackedShipment.estimatedDelivery 
                          ? formatDate(trackedShipment.estimatedDelivery)
                          : "Не указано"}
                      </p>
                    </div>
                  </div>
                </div>

                {/* История отслеживания */}
                <div>
                  <h3 className="text-lg font-medium mb-4">История отслеживания</h3>
                  <div className="space-y-4">
                    {getTrackingHistory(trackedShipment).map((event, index) => (
                      <div key={index} className="flex items-start space-x-4">
                        <div className={cn(
                          "flex-shrink-0 w-3 h-3 rounded-full mt-2",
                          index === 0 ? "bg-green-500" : "bg-gray-300"
                        )} />
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <p className="font-medium">{event.status}</p>
                            <p className="text-sm text-muted-foreground">
                              {formatDate(event.timestamp)}
                            </p>
                          </div>
                          <p className="text-sm text-muted-foreground">{event.location}</p>
                          <p className="text-sm">{event.description}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Информация о маршруте */}
                {shipmentRoute && (
                  <div className="border-t pt-4">
                    <h3 className="text-lg font-medium mb-4">Информация о маршруте</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm font-medium">Маршрут</p>
                        <p className="text-sm text-muted-foreground">{shipmentRoute.routeName}</p>
                      </div>
                      <div>
                        <p className="text-sm font-medium">Водитель</p>
                        <p className="text-sm text-muted-foreground">{shipmentRoute.driverName}</p>
                      </div>
                      <div>
                        <p className="text-sm font-medium">Транспорт</p>
                        <p className="text-sm text-muted-foreground">{shipmentRoute.vehicleNumber}</p>
                      </div>
                      <div>
                        <p className="text-sm font-medium">Расстояние</p>
                        <p className="text-sm text-muted-foreground">{shipmentRoute.distance || "Не указано"}</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center py-8">
                <AlertCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-lg font-medium text-muted-foreground">
                  Отправление не найдено
                </p>
                <p className="text-sm text-muted-foreground">
                  Проверьте правильность введенного трек-номера
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="active" className="space-y-4">
        <TabsList>
          <TabsTrigger value="active">Активные отправления</TabsTrigger>
          <TabsTrigger value="map">Карта в реальном времени</TabsTrigger>
        </TabsList>

        <TabsContent value="active" className="space-y-4">
          <div className="grid gap-4">
            {activeShipments.length > 0 ? (
              activeShipments.map((shipment) => (
                <Card key={shipment.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center justify-center w-10 h-10 bg-blue-100 rounded-full">
                          <Truck className="h-5 w-5 text-blue-600" />
                        </div>
                        <div>
                          <p className="font-medium">Трек-номер: {shipment.trackingNumber}</p>
                          <p className="text-sm text-muted-foreground">
                            Создан: {formatDate(shipment.createdAt)}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <Badge className={getStatusColor(shipment.status)}>
                          {shipment.status === "pending" ? "Ожидает" :
                           shipment.status === "in_transit" ? "В пути" :
                           shipment.status === "delivered" ? "Доставлено" : shipment.status}
                        </Badge>
                        <p className="text-sm text-muted-foreground mt-1">
                          {shipment.currentLocation || "Местоположение не определено"}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12">
                  <Package className="h-12 w-12 text-muted-foreground mb-4" />
                  <p className="text-lg font-medium text-muted-foreground">Нет активных отправлений</p>
                  <p className="text-sm text-muted-foreground">Все отправления доставлены</p>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="map" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <MapPin className="h-5 w-5" />
                <span>Отслеживание в реальном времени</span>
              </CardTitle>
              <CardDescription>
                Местоположение всех активных отправлений на карте
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="bg-gray-100 rounded-lg p-8 text-center">
                <MapPin className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <p className="text-lg font-medium text-gray-600 mb-2">Интерактивная карта</p>
                <p className="text-sm text-gray-500 mb-4">
                  Здесь будет отображаться карта с местоположением всех активных отправлений в реальном времени
                </p>
                <Badge variant="outline">Функция в разработке</Badge>
              </div>
              
              {/* Список активных точек на карте */}
              <div className="mt-6 space-y-2">
                <h3 className="font-medium">Активные точки на карте:</h3>
                {activeShipments.map((shipment) => (
                  <div key={shipment.id} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 bg-blue-500 rounded-full" />
                      <span className="text-sm font-medium">{shipment.trackingNumber}</span>
                    </div>
                    <span className="text-sm text-muted-foreground">
                      {shipment.currentLocation || "Координаты не определены"}
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}