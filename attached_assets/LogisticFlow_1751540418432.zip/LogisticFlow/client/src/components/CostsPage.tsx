import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Calculator, DollarSign, TrendingUp, Percent, Fuel, MapPin } from "lucide-react";
import { formatCurrency } from "@/lib/utils";

export default function CostsPage() {
  const [calculationType, setCalculationType] = useState("delivery");
  const [distance, setDistance] = useState("");
  const [weight, setWeight] = useState("");
  const [fuelPrice, setFuelPrice] = useState("55");
  const [fuelConsumption, setFuelConsumption] = useState("12");
  const [driverRate, setDriverRate] = useState("800");
  const [orderValue, setOrderValue] = useState("");
  const [calculatedCost, setCalculatedCost] = useState<number | null>(null);

  const { data: orders = [] } = useQuery({
    queryKey: ["/api/orders"],
  });

  const { data: routes = [] } = useQuery({
    queryKey: ["/api/routes"],
  });

  const calculateDeliveryCost = () => {
    const dist = parseFloat(distance) || 0;
    const wgt = parseFloat(weight) || 0;
    const fuel = parseFloat(fuelPrice) || 55;
    const consumption = parseFloat(fuelConsumption) || 12;
    const driver = parseFloat(driverRate) || 800;
    
    // Расчет стоимости топлива
    const fuelCost = (dist / 100) * consumption * fuel;
    
    // Базовая стоимость за километр
    const baseKmCost = dist * 15;
    
    // Доплата за вес (за каждые 100 кг)
    const weightCost = Math.ceil(wgt / 100) * 200;
    
    // Оплата водителя (процент от расстояния)
    const driverCost = (dist / 100) * driver;
    
    // Накладные расходы (20%)
    const overheadCost = (fuelCost + baseKmCost + weightCost + driverCost) * 0.2;
    
    const total = fuelCost + baseKmCost + weightCost + driverCost + overheadCost;
    setCalculatedCost(total);
  };

  const calculateOrderCost = () => {
    const value = parseFloat(orderValue) || 0;
    const dist = parseFloat(distance) || 0;
    
    // Базовая стоимость логистики (5% от стоимости заказа)
    const logisticsCost = value * 0.05;
    
    // Стоимость доставки
    const deliveryCost = dist * 18;
    
    // Страховка (1% от стоимости заказа)
    const insuranceCost = value * 0.01;
    
    // Комиссия за обработку (фиксированная)
    const processingCost = 500;
    
    const total = logisticsCost + deliveryCost + insuranceCost + processingCost;
    setCalculatedCost(total);
  };

  const calculateRouteCost = () => {
    const dist = parseFloat(distance) || 0;
    const fuel = parseFloat(fuelPrice) || 55;
    const consumption = parseFloat(fuelConsumption) || 12;
    const driver = parseFloat(driverRate) || 800;
    
    // Стоимость топлива для всего маршрута
    const totalFuelCost = (dist / 100) * consumption * fuel;
    
    // Оплата водителя за день
    const driverCost = driver;
    
    // Амортизация транспорта
    const vehicleCost = dist * 8;
    
    // Накладные расходы
    const overheadCost = (totalFuelCost + driverCost + vehicleCost) * 0.15;
    
    const total = totalFuelCost + driverCost + vehicleCost + overheadCost;
    setCalculatedCost(total);
  };

  const handleCalculate = () => {
    switch (calculationType) {
      case "delivery":
        calculateDeliveryCost();
        break;
      case "order":
        calculateOrderCost();
        break;
      case "route":
        calculateRouteCost();
        break;
    }
  };

  const totalOrderValue = orders.reduce((sum: number, order: any) => 
    sum + parseFloat(order.amount || "0"), 0
  );

  const totalRouteCost = routes.reduce((sum: number, route: any) => 
    sum + parseFloat(route.cost || "0"), 0
  );

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Общая выручка</p>
                <p className="text-2xl font-bold">{formatCurrency(totalOrderValue)}</p>
              </div>
              <DollarSign className="w-8 h-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Стоимость маршрутов</p>
                <p className="text-2xl font-bold">{formatCurrency(totalRouteCost)}</p>
              </div>
              <MapPin className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Прибыль</p>
                <p className="text-2xl font-bold text-green-600">
                  {formatCurrency(totalOrderValue - totalRouteCost)}
                </p>
              </div>
              <TrendingUp className="w-8 h-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Рентабельность</p>
                <p className="text-2xl font-bold">
                  {totalOrderValue > 0 
                    ? `${(((totalOrderValue - totalRouteCost) / totalOrderValue) * 100).toFixed(1)}%`
                    : "0%"
                  }
                </p>
              </div>
              <Percent className="w-8 h-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Cost Calculator */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Calculator className="w-5 h-5 mr-2" />
              Калькулятор стоимости
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-600">Тип расчета</label>
              <Select value={calculationType} onValueChange={setCalculationType}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="delivery">Стоимость доставки</SelectItem>
                  <SelectItem value="order">Стоимость заказа</SelectItem>
                  <SelectItem value="route">Стоимость маршрута</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-600">Расстояние (км)</label>
                <Input
                  type="number"
                  value={distance}
                  onChange={(e) => setDistance(e.target.value)}
                  placeholder="0"
                />
              </div>
              
              {calculationType === "delivery" && (
                <div>
                  <label className="text-sm font-medium text-gray-600">Вес (кг)</label>
                  <Input
                    type="number"
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    placeholder="0"
                  />
                </div>
              )}

              {calculationType === "order" && (
                <div>
                  <label className="text-sm font-medium text-gray-600">Стоимость заказа (₽)</label>
                  <Input
                    type="number"
                    value={orderValue}
                    onChange={(e) => setOrderValue(e.target.value)}
                    placeholder="0"
                  />
                </div>
              )}

              <div>
                <label className="text-sm font-medium text-gray-600">Цена топлива (₽/л)</label>
                <Input
                  type="number"
                  value={fuelPrice}
                  onChange={(e) => setFuelPrice(e.target.value)}
                  placeholder="55"
                />
              </div>

              <div>
                <label className="text-sm font-medium text-gray-600">Расход (л/100км)</label>
                <Input
                  type="number"
                  value={fuelConsumption}
                  onChange={(e) => setFuelConsumption(e.target.value)}
                  placeholder="12"
                />
              </div>

              <div>
                <label className="text-sm font-medium text-gray-600">Оплата водителя (₽/день)</label>
                <Input
                  type="number"
                  value={driverRate}
                  onChange={(e) => setDriverRate(e.target.value)}
                  placeholder="800"
                />
              </div>
            </div>

            <Button onClick={handleCalculate} className="w-full">
              <Calculator className="w-4 h-4 mr-2" />
              Рассчитать стоимость
            </Button>

            {calculatedCost !== null && (
              <div className="mt-4 p-4 bg-primary/10 rounded-lg">
                <div className="text-center">
                  <p className="text-sm text-gray-600">Расчетная стоимость</p>
                  <p className="text-3xl font-bold text-primary">
                    {formatCurrency(calculatedCost)}
                  </p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Cost Breakdown */}
        <Card>
          <CardHeader>
            <CardTitle>Структура затрат</CardTitle>
          </CardHeader>
          <CardContent>
            {calculatedCost !== null ? (
              <div className="space-y-4">
                {calculationType === "delivery" && (
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Топливо</span>
                      <span className="font-medium">
                        {formatCurrency(((parseFloat(distance) || 0) / 100) * (parseFloat(fuelConsumption) || 12) * (parseFloat(fuelPrice) || 55))}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Базовая стоимость</span>
                      <span className="font-medium">
                        {formatCurrency((parseFloat(distance) || 0) * 15)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Доплата за вес</span>
                      <span className="font-medium">
                        {formatCurrency(Math.ceil((parseFloat(weight) || 0) / 100) * 200)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Оплата водителя</span>
                      <span className="font-medium">
                        {formatCurrency(((parseFloat(distance) || 0) / 100) * (parseFloat(driverRate) || 800))}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Накладные расходы (20%)</span>
                      <span className="font-medium">
                        {formatCurrency(calculatedCost * 0.167)} {/* 20% от основной суммы */}
                      </span>
                    </div>
                  </div>
                )}

                {calculationType === "order" && (
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Логистика (5%)</span>
                      <span className="font-medium">
                        {formatCurrency((parseFloat(orderValue) || 0) * 0.05)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Доставка</span>
                      <span className="font-medium">
                        {formatCurrency((parseFloat(distance) || 0) * 18)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Страховка (1%)</span>
                      <span className="font-medium">
                        {formatCurrency((parseFloat(orderValue) || 0) * 0.01)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Обработка</span>
                      <span className="font-medium">{formatCurrency(500)}</span>
                    </div>
                  </div>
                )}

                {calculationType === "route" && (
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Топливо</span>
                      <span className="font-medium">
                        {formatCurrency(((parseFloat(distance) || 0) / 100) * (parseFloat(fuelConsumption) || 12) * (parseFloat(fuelPrice) || 55))}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Оплата водителя</span>
                      <span className="font-medium">
                        {formatCurrency(parseFloat(driverRate) || 800)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Амортизация</span>
                      <span className="font-medium">
                        {formatCurrency((parseFloat(distance) || 0) * 8)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Накладные (15%)</span>
                      <span className="font-medium">
                        {formatCurrency(calculatedCost * 0.13)} {/* 15% от основной суммы */}
                      </span>
                    </div>
                  </div>
                )}

                <div className="border-t pt-3">
                  <div className="flex justify-between items-center text-lg font-bold">
                    <span>Итого:</span>
                    <span className="text-primary">{formatCurrency(calculatedCost)}</span>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <Calculator className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                <p className="text-gray-500">Выполните расчет для просмотра структуры затрат</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Cost Analysis */}
      <Card>
        <CardHeader>
          <CardTitle>Анализ затрат по типам</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <Fuel className="w-8 h-8 text-blue-500 mx-auto mb-2" />
              <h3 className="font-semibold text-blue-900">Переменные затраты</h3>
              <p className="text-sm text-blue-700 mt-1">
                Топливо, километраж, вес груза
              </p>
              <p className="text-2xl font-bold text-blue-600 mt-2">
                {formatCurrency(totalRouteCost * 0.6)}
              </p>
            </div>
            
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <DollarSign className="w-8 h-8 text-green-500 mx-auto mb-2" />
              <h3 className="font-semibold text-green-900">Постоянные затраты</h3>
              <p className="text-sm text-green-700 mt-1">
                Зарплата, аренда, страховка
              </p>
              <p className="text-2xl font-bold text-green-600 mt-2">
                {formatCurrency(totalRouteCost * 0.3)}
              </p>
            </div>
            
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <TrendingUp className="w-8 h-8 text-purple-500 mx-auto mb-2" />
              <h3 className="font-semibold text-purple-900">Накладные расходы</h3>
              <p className="text-sm text-purple-700 mt-1">
                Управление, обработка, прочее
              </p>
              <p className="text-2xl font-bold text-purple-600 mt-2">
                {formatCurrency(totalRouteCost * 0.1)}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
