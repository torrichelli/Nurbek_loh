import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Plus, Search, Package, ArrowUp, ArrowDown, RefreshCw, Truck, Clock } from "lucide-react";
import { formatDate } from "@/lib/utils";
import { insertWarehouseOperationSchema, type WarehouseOperation } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";

const operationFormSchema = insertWarehouseOperationSchema.extend({
  itemId: z.number().min(1, "Выберите товар"),
  quantity: z.number().min(1, "Количество должно быть больше 0"),
  operatorName: z.string().min(1, "Имя оператора обязательно"),
});

type OperationFormData = z.infer<typeof operationFormSchema>;

export default function WarehousePage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [typeFilter, setTypeFilter] = useState<string>("all");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const { toast } = useToast();

  const { data: operations = [], isLoading } = useQuery<WarehouseOperation[]>({
    queryKey: ["/api/warehouse-operations"],
  });

  const { data: inventoryItems = [] } = useQuery({
    queryKey: ["/api/inventory"],
  });

  const createOperationMutation = useMutation({
    mutationFn: async (data: OperationFormData) => {
      const response = await apiRequest("POST", "/api/warehouse-operations", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/warehouse-operations"] });
      queryClient.invalidateQueries({ queryKey: ["/api/inventory"] });
      setIsCreateDialogOpen(false);
      toast({
        title: "Успешно",
        description: "Операция зарегистрирована",
      });
      form.reset();
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось создать операцию",
        variant: "destructive",
      });
    },
  });

  const form = useForm<OperationFormData>({
    resolver: zodResolver(operationFormSchema),
    defaultValues: {
      type: "receipt",
      itemId: 0,
      quantity: 1,
      reason: "",
      operatorName: "",
    },
  });

  const filteredOperations = operations.filter(operation => {
    const operatorName = operation.operatorName || "";
    const reason = operation.reason || "";
    
    const matchesSearch = operatorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         reason.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = typeFilter === "all" || operation.type === typeFilter;
    return matchesSearch && matchesType;
  });

  const onSubmit = (data: OperationFormData) => {
    createOperationMutation.mutate(data);
  };

  const getOperationIcon = (type: string) => {
    switch (type) {
      case "receipt": return ArrowUp;
      case "shipment": return ArrowDown;
      case "adjustment": return RefreshCw;
      case "transfer": return Truck;
      default: return Package;
    }
  };

  const getOperationColor = (type: string) => {
    switch (type) {
      case "receipt": return "bg-green-100 text-green-800";
      case "shipment": return "bg-blue-100 text-blue-800";
      case "adjustment": return "bg-yellow-100 text-yellow-800";
      case "transfer": return "bg-purple-100 text-purple-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getOperationText = (type: string) => {
    switch (type) {
      case "receipt": return "Приход";
      case "shipment": return "Отгрузка";
      case "adjustment": return "Корректировка";
      case "transfer": return "Перемещение";
      default: return type;
    }
  };

  const todayOperations = operations.filter(op => {
    const today = new Date();
    const opDate = new Date(op.createdAt);
    return opDate.toDateString() === today.toDateString();
  });

  const receiptOperations = operations.filter(op => op.type === "receipt");
  const shipmentOperations = operations.filter(op => op.type === "shipment");

  if (isLoading) {
    return <div className="space-y-4">
      {[...Array(5)].map((_, i) => (
        <Card key={i} className="animate-pulse">
          <CardContent className="p-6">
            <div className="h-20 bg-gray-200 rounded"></div>
          </CardContent>
        </Card>
      ))}
    </div>;
  }

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Операций сегодня</p>
                <p className="text-2xl font-bold">{todayOperations.length}</p>
              </div>
              <Clock className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Поступления</p>
                <p className="text-2xl font-bold text-green-600">{receiptOperations.length}</p>
              </div>
              <ArrowUp className="w-8 h-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Отгрузки</p>
                <p className="text-2xl font-bold text-blue-600">{shipmentOperations.length}</p>
              </div>
              <ArrowDown className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Всего операций</p>
                <p className="text-2xl font-bold">{operations.length}</p>
              </div>
              <Package className="w-8 h-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Поиск операций..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-64"
            />
          </div>
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Фильтр по типу" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Все типы</SelectItem>
              <SelectItem value="receipt">Приход</SelectItem>
              <SelectItem value="shipment">Отгрузка</SelectItem>
              <SelectItem value="adjustment">Корректировка</SelectItem>
              <SelectItem value="transfer">Перемещение</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Новая операция
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Создать складскую операцию</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="type"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Тип операции</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="receipt">Приход товара</SelectItem>
                            <SelectItem value="shipment">Отгрузка товара</SelectItem>
                            <SelectItem value="adjustment">Корректировка остатков</SelectItem>
                            <SelectItem value="transfer">Перемещение товара</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="itemId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Товар</FormLabel>
                        <Select onValueChange={(value) => field.onChange(parseInt(value))}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Выберите товар" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {inventoryItems.map((item: any) => (
                              <SelectItem key={item.id} value={item.id.toString()}>
                                {item.itemName} ({item.itemCode})
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="quantity"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Количество</FormLabel>
                        <FormControl>
                          <Input 
                            {...field} 
                            type="number" 
                            onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="operatorName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Оператор</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="Имя сотрудника" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="reason"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Причина/Примечание</FormLabel>
                      <FormControl>
                        <Textarea {...field} placeholder="Описание операции, номер документа, причина корректировки" rows={3} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex justify-end space-x-2">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setIsCreateDialogOpen(false)}
                  >
                    Отмена
                  </Button>
                  <Button type="submit" disabled={createOperationMutation.isPending}>
                    {createOperationMutation.isPending ? "Создание..." : "Создать операцию"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Operations List */}
      <div className="space-y-4">
        {filteredOperations.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-gray-500">Операции не найдены</p>
            </CardContent>
          </Card>
        ) : (
          filteredOperations.map((operation) => {
            const OperationIcon = getOperationIcon(operation.type);
            const relatedItem = inventoryItems.find((item: any) => item.id === operation.itemId);
            
            return (
              <Card key={operation.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                        <OperationIcon className="w-6 h-6 text-primary" />
                      </div>
                      <div>
                        <div className="flex items-center space-x-2">
                          <Badge className={getOperationColor(operation.type)}>
                            {getOperationText(operation.type)}
                          </Badge>
                          <span className="text-lg font-semibold">
                            {operation.type === "shipment" ? "-" : "+"}{operation.quantity}
                          </span>
                        </div>
                        <p className="text-gray-900 font-medium">
                          {relatedItem?.itemName || "Неизвестный товар"}
                        </p>
                        <p className="text-sm text-gray-500">
                          Код: {relatedItem?.itemCode || "—"}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-6">
                      <div className="text-center">
                        <p className="text-sm text-gray-600">Оператор</p>
                        <p className="font-medium">{operation.operatorName}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-sm text-gray-600">Дата/Время</p>
                        <p className="font-medium">{formatDate(operation.createdAt)}</p>
                      </div>
                      <div className="text-right max-w-48">
                        <p className="text-sm text-gray-600">Причина</p>
                        <p className="text-sm">{operation.reason || "—"}</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Быстрые операции</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Button
              variant="outline"
              className="h-20 flex flex-col items-center justify-center space-y-2 border-2 border-dashed hover:border-green-500 hover:bg-green-50"
              onClick={() => {
                form.setValue("type", "receipt");
                setIsCreateDialogOpen(true);
              }}
            >
              <ArrowUp className="w-6 h-6 text-green-500" />
              <span className="text-sm text-gray-600">Приход товара</span>
            </Button>
            
            <Button
              variant="outline"
              className="h-20 flex flex-col items-center justify-center space-y-2 border-2 border-dashed hover:border-blue-500 hover:bg-blue-50"
              onClick={() => {
                form.setValue("type", "shipment");
                setIsCreateDialogOpen(true);
              }}
            >
              <ArrowDown className="w-6 h-6 text-blue-500" />
              <span className="text-sm text-gray-600">Отгрузка товара</span>
            </Button>
            
            <Button
              variant="outline"
              className="h-20 flex flex-col items-center justify-center space-y-2 border-2 border-dashed hover:border-yellow-500 hover:bg-yellow-50"
              onClick={() => {
                form.setValue("type", "adjustment");
                setIsCreateDialogOpen(true);
              }}
            >
              <RefreshCw className="w-6 h-6 text-yellow-500" />
              <span className="text-sm text-gray-600">Корректировка</span>
            </Button>
            
            <Button
              variant="outline"
              className="h-20 flex flex-col items-center justify-center space-y-2 border-2 border-dashed hover:border-purple-500 hover:bg-purple-50"
              onClick={() => {
                form.setValue("type", "transfer");
                setIsCreateDialogOpen(true);
              }}
            >
              <Truck className="w-6 h-6 text-purple-500" />
              <span className="text-sm text-gray-600">Перемещение</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
