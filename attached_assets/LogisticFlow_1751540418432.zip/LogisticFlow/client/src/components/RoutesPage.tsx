import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Plus, Search, Edit, Route as RouteIcon, Truck, Clock, MapPin, Zap } from "lucide-react";
import { formatCurrency, formatDate, getStatusColor, getStatusText } from "@/lib/utils";
import { insertRouteSchema, type Route } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";

const routeFormSchema = insertRouteSchema.extend({
  orderIds: z.array(z.number()).min(1, "Добавьте хотя бы один заказ"),
  distance: z.string().optional(),
  estimatedTime: z.number().optional(),
  cost: z.string().optional(),
});

type RouteFormData = z.infer<typeof routeFormSchema>;

export default function RoutesPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isOptimizing, setIsOptimizing] = useState(false);
  const { toast } = useToast();

  const { data: routes = [], isLoading } = useQuery<Route[]>({
    queryKey: ["/api/routes"],
  });

  const { data: orders = [] } = useQuery({
    queryKey: ["/api/orders"],
  });

  const createRouteMutation = useMutation({
    mutationFn: async (data: RouteFormData) => {
      const response = await apiRequest("POST", "/api/routes", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/routes"] });
      setIsCreateDialogOpen(false);
      toast({
        title: "Успешно",
        description: "Маршрут создан успешно",
      });
      form.reset();
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось создать маршрут",
        variant: "destructive",
      });
    },
  });

  const updateRouteMutation = useMutation({
    mutationFn: async ({ id, status }: { id: number; status: string }) => {
      const response = await apiRequest("PUT", `/api/routes/${id}`, { status });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/routes"] });
      toast({
        title: "Успешно",
        description: "Статус маршрута обновлен",
      });
    },
  });

  const form = useForm<RouteFormData>({
    resolver: zodResolver(routeFormSchema),
    defaultValues: {
      routeName: "",
      driverName: "",
      vehicleNumber: "",
      status: "planned",
      orderIds: [],
      distance: "0",
      estimatedTime: 0,
      cost: "0",
    },
  });

  const availableOrders = orders.filter((order: any) => 
    order.status === "processing" || order.status === "pending"
  );

  const filteredRoutes = routes.filter(route => {
    const matchesSearch = route.routeName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         route.driverName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         route.vehicleNumber.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "all" || route.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const onSubmit = (data: RouteFormData) => {
    // Calculate estimated values based on number of orders
    const orderCount = data.orderIds.length;
    const estimatedDistance = orderCount * 25; // Примерно 25 км на заказ
    const estimatedTime = orderCount * 30; // Примерно 30 минут на заказ
    const estimatedCost = estimatedDistance * 22; // 22 рубля за км

    const routeData = {
      ...data,
      distance: estimatedDistance.toString(),
      estimatedTime,
      cost: estimatedCost.toString(),
    };

    createRouteMutation.mutate(routeData);
  };

  const optimizeRoutes = async () => {
    setIsOptimizing(true);
    
    // Simulate route optimization
    setTimeout(() => {
      setIsOptimizing(false);
      toast({
        title: "Оптимизация завершена",
        description: "Маршруты были оптимизированы для лучшей эффективности",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/routes"] });
    }, 3000);
  };

  if (isLoading) {
    return <div className="space-y-4">
      {[...Array(5)].map((_, i) => (
        <Card key={i} className="animate-pulse">
          <CardContent className="p-6">
            <div className="h-20 bg-gray-200 rounded"></div>
          </CardContent>
        </Card>
      ))}
    </div>;
  }

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Всего маршрутов</p>
                <p className="text-2xl font-bold">{routes.length}</p>
              </div>
              <RouteIcon className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Активные</p>
                <p className="text-2xl font-bold text-green-600">
                  {routes.filter(r => r.status === "active").length}
                </p>
              </div>
              <Truck className="w-8 h-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Планируемые</p>
                <p className="text-2xl font-bold text-blue-600">
                  {routes.filter(r => r.status === "planned").length}
                </p>
              </div>
              <Clock className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Общая стоимость</p>
                <p className="text-2xl font-bold">
                  {formatCurrency(
                    routes.reduce((sum, route) => sum + parseFloat(route.cost || "0"), 0)
                  )}
                </p>
              </div>
              <MapPin className="w-8 h-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Поиск маршрутов..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-64"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Фильтр по статусу" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Все статусы</SelectItem>
              <SelectItem value="planned">Планируется</SelectItem>
              <SelectItem value="active">Активен</SelectItem>
              <SelectItem value="completed">Завершен</SelectItem>
              <SelectItem value="cancelled">Отменен</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex space-x-2">
          <Button
            variant="outline"
            onClick={optimizeRoutes}
            disabled={isOptimizing}
          >
            {isOptimizing ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary mr-2"></div>
                Оптимизация...
              </>
            ) : (
              <>
                <Zap className="w-4 h-4 mr-2" />
                Оптимизировать
              </>
            )}
          </Button>

          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Создать маршрут
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Создать новый маршрут</DialogTitle>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="routeName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Название маршрута</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="Маршрут №1" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="driverName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Водитель</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="Иванов И.И." />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="vehicleNumber"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Номер транспорта</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="А123БВ777" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="status"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Статус</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="planned">Планируется</SelectItem>
                              <SelectItem value="active">Активен</SelectItem>
                              <SelectItem value="completed">Завершен</SelectItem>
                              <SelectItem value="cancelled">Отменен</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="orderIds"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Заказы для доставки</FormLabel>
                        <div className="grid grid-cols-1 gap-2 max-h-40 overflow-y-auto border rounded p-3">
                          {availableOrders.map((order: any) => (
                            <label key={order.id} className="flex items-center space-x-2 cursor-pointer">
                              <input
                                type="checkbox"
                                checked={field.value.includes(order.id)}
                                onChange={(e) => {
                                  const newValue = e.target.checked
                                    ? [...field.value, order.id]
                                    : field.value.filter(id => id !== order.id);
                                  field.onChange(newValue);
                                }}
                                className="rounded border-gray-300"
                              />
                              <span className="text-sm">
                                {order.orderNumber} - {order.customer} ({formatCurrency(order.amount)})
                              </span>
                            </label>
                          ))}
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="flex justify-end space-x-2">
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => setIsCreateDialogOpen(false)}
                    >
                      Отмена
                    </Button>
                    <Button type="submit" disabled={createRouteMutation.isPending}>
                      {createRouteMutation.isPending ? "Создание..." : "Создать маршрут"}
                    </Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Routes List */}
      <div className="space-y-4">
        {filteredRoutes.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-gray-500">Маршруты не найдены</p>
            </CardContent>
          </Card>
        ) : (
          filteredRoutes.map((route) => (
            <Card key={route.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                      <RouteIcon className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <div className="flex items-center space-x-2">
                        <h3 className="font-semibold text-lg">{route.routeName}</h3>
                        <Badge className={getStatusColor(route.status)}>
                          {getStatusText(route.status)}
                        </Badge>
                      </div>
                      <p className="text-gray-600">Водитель: {route.driverName}</p>
                      <p className="text-sm text-gray-500">Транспорт: {route.vehicleNumber}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-6">
                    <div className="text-center">
                      <p className="text-sm text-gray-600">Заказов</p>
                      <p className="text-xl font-bold">
                        {Array.isArray(route.orderIds) ? route.orderIds.length : 0}
                      </p>
                    </div>
                    <div className="text-center">
                      <p className="text-sm text-gray-600">Расстояние</p>
                      <p className="text-lg font-semibold">
                        {route.distance ? `${route.distance} км` : "—"}
                      </p>
                    </div>
                    <div className="text-center">
                      <p className="text-sm text-gray-600">Время</p>
                      <p className="text-lg font-semibold">
                        {route.estimatedTime ? `${Math.floor(route.estimatedTime / 60)}ч ${route.estimatedTime % 60}м` : "—"}
                      </p>
                    </div>
                    <div className="text-center">
                      <p className="text-sm text-gray-600">Стоимость</p>
                      <p className="text-lg font-semibold">
                        {route.cost ? formatCurrency(route.cost) : "—"}
                      </p>
                    </div>
                    
                    <div className="flex space-x-2">
                      {route.status === "planned" && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => updateRouteMutation.mutate({ id: route.id, status: "active" })}
                          disabled={updateRouteMutation.isPending}
                        >
                          <Edit className="w-4 h-4 mr-1" />
                          Запустить
                        </Button>
                      )}
                      
                      {route.status === "active" && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => updateRouteMutation.mutate({ id: route.id, status: "completed" })}
                          disabled={updateRouteMutation.isPending}
                        >
                          <Edit className="w-4 h-4 mr-1" />
                          Завершить
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
