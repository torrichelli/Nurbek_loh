import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  ClipboardList, 
  TrendingUp, 
  CheckCircle, 
  AlertTriangle,
  Package,
  Route,
  Plus,
  Truck,
  FileText,
  BarChart3
} from "lucide-react";
import { cn, formatCurrency } from "@/lib/utils";

interface DashboardMetrics {
  activeOrders: number;
  inTransit: number;
  deliveredToday: number;
  issues: number;
  activeOrdersChange: string;
  inTransitChange: string;
  deliveredChange: string;
  issuesChange: string;
}

export default function Dashboard() {
  const { data: metrics, isLoading } = useQuery<DashboardMetrics>({
    queryKey: ["/api/dashboard/metrics"],
  });

  const { data: lowStockItems = [] } = useQuery({
    queryKey: ["/api/inventory/low-stock"],
  });

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-20 bg-gray-200 rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8 p-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Дашборд логистики
          </h1>
          <p className="text-gray-600 mt-2">Управление грузоперевозками и складом</p>
        </div>
        <div className="text-sm text-gray-500 glass-card px-4 py-2 rounded-lg">
          Обновлено: {new Date().toLocaleString('ru-RU')}
        </div>
      </div>

      {/* Key Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="hover-lift modern-shadow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Активные заказы</p>
                <p className="text-3xl font-bold text-gray-900 mt-2">
                  {metrics?.activeOrders || 0}
                </p>
                <p className="text-sm text-green-600 mt-1 flex items-center">
                  <TrendingUp className="w-3 h-3 mr-1" />
                  {metrics?.activeOrdersChange || "+12%"}
                </p>
              </div>
              <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
                <ClipboardList className="text-primary w-6 h-6" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">В пути</p>
                <p className="text-3xl font-bold text-gray-900 mt-2">
                  {metrics?.inTransit || 0}
                </p>
                <p className="text-sm text-green-600 mt-1 flex items-center">
                  <TrendingUp className="w-3 h-3 mr-1" />
                  {metrics?.inTransitChange || "+5%"}
                </p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                <Truck className="text-green-600 w-6 h-6" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Доставлено сегодня</p>
                <p className="text-3xl font-bold text-gray-900 mt-2">
                  {metrics?.deliveredToday || 0}
                </p>
                <p className="text-sm text-green-600 mt-1 flex items-center">
                  <TrendingUp className="w-3 h-3 mr-1" />
                  {metrics?.deliveredChange || "+8%"}
                </p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                <CheckCircle className="text-green-600 w-6 h-6" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Проблемы</p>
                <p className="text-3xl font-bold text-gray-900 mt-2">
                  {metrics?.issues || 0}
                </p>
                <p className="text-sm text-red-600 mt-1 flex items-center">
                  <TrendingUp className="w-3 h-3 mr-1 rotate-180" />
                  {metrics?.issuesChange || "-3%"}
                </p>
              </div>
              <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center">
                <AlertTriangle className="text-red-600 w-6 h-6" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts and Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Delivery Performance Chart */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Производительность доставки</CardTitle>
            <select className="text-sm border border-gray-300 rounded-lg px-3 py-1 focus:ring-2 focus:ring-primary focus:border-transparent outline-none">
              <option>За неделю</option>
              <option>За месяц</option>
              <option>За квартал</option>
            </select>
          </CardHeader>
          <CardContent>
            <div className="h-64 bg-gray-50 rounded-lg flex items-center justify-center border-2 border-dashed border-gray-300">
              <div className="text-center">
                <BarChart3 className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                <p className="text-gray-500 text-sm">График производительности доставки</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Recent Orders */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Последние заказы</CardTitle>
            <Button variant="link" className="text-primary">
              Показать все
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            {[
              { id: "#ORD-2024-001", customer: "ООО \"Альфа Трейд\"", amount: "45,230", status: "В обработке" },
              { id: "#ORD-2024-002", customer: "ИП Сидоров В.А.", amount: "12,850", status: "В пути" },
              { id: "#ORD-2024-003", customer: "ООО \"Бета Логистик\"", amount: "78,920", status: "Доставлен" },
            ].map((order, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                    <Package className="text-primary w-5 h-5" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{order.id}</p>
                    <p className="text-sm text-gray-600">{order.customer}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-medium text-gray-900">{formatCurrency(order.amount)}</p>
                  <Badge
                    className={cn(
                      "text-xs",
                      order.status === "В обработке" && "bg-yellow-100 text-yellow-800",
                      order.status === "В пути" && "bg-blue-100 text-blue-800",
                      order.status === "Доставлен" && "bg-green-100 text-green-800"
                    )}
                  >
                    {order.status}
                  </Badge>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Inventory Status and Route Optimization */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Inventory Alerts */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Складские уведомления</CardTitle>
            <Badge variant="destructive" className="text-xs">
              {lowStockItems.length}
            </Badge>
          </CardHeader>
          <CardContent className="space-y-3">
            {lowStockItems.length === 0 ? (
              <p className="text-sm text-gray-500 text-center py-4">
                Нет критических уведомлений
              </p>
            ) : (
              lowStockItems.map((item: any) => (
                <div
                  key={item.id}
                  className={cn(
                    "flex items-start space-x-3 p-3 border rounded-lg",
                    item.quantity === 0
                      ? "bg-red-50 border-red-200"
                      : "bg-yellow-50 border-yellow-200"
                  )}
                >
                  <AlertTriangle
                    className={cn(
                      "w-4 h-4 mt-0.5",
                      item.quantity === 0 ? "text-red-500" : "text-yellow-500"
                    )}
                  />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-900">{item.itemName}</p>
                    <p className="text-xs text-gray-600">
                      {item.quantity === 0
                        ? "Нет в наличии"
                        : `Критически низкий запас: ${item.quantity} ${item.unit}`}
                    </p>
                  </div>
                </div>
              ))
            )}
          </CardContent>
        </Card>

        {/* Route Optimization */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Оптимизация маршрутов</CardTitle>
              <Button className="bg-primary hover:bg-primary/90">
                <Route className="w-4 h-4 mr-2" />
                Оптимизировать
              </Button>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[
                  {
                    name: "Маршрут №1",
                    driver: "Иванов И.И.",
                    orders: 8,
                    distance: "156 км",
                    time: "4ч 20м",
                    cost: "3,420",
                    status: "Активен",
                  },
                  {
                    name: "Маршрут №2",
                    driver: "Петров П.П.",
                    orders: 12,
                    distance: "203 км",
                    time: "6ч 15м",
                    cost: "4,890",
                    status: "Планируется",
                  },
                ].map((route, index) => (
                  <div
                    key={index}
                    className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-2">
                        <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                          <Route className="text-primary w-4 h-4" />
                        </div>
                        <div>
                          <p className="font-medium text-gray-900">{route.name}</p>
                          <p className="text-xs text-gray-600">Водитель: {route.driver}</p>
                        </div>
                      </div>
                      <Badge
                        className={cn(
                          "text-xs",
                          route.status === "Активен" && "bg-green-100 text-green-800",
                          route.status === "Планируется" && "bg-blue-100 text-blue-800"
                        )}
                      >
                        {route.status}
                      </Badge>
                    </div>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Заказов:</span>
                        <span className="font-medium">{route.orders}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Расстояние:</span>
                        <span className="font-medium">{route.distance}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Время:</span>
                        <span className="font-medium">{route.time}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Стоимость:</span>
                        <span className="font-medium">{formatCurrency(route.cost)}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Быстрые действия</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { icon: Plus, label: "Создать заказ", href: "/orders" },
              { icon: Truck, label: "Добавить отправку", href: "/shipments" },
              { icon: FileText, label: "Создать счет", href: "/invoices" },
              { icon: BarChart3, label: "Создать отчет", href: "/" },
            ].map((action, index) => {
              const Icon = action.icon;
              return (
                <Button
                  key={index}
                  variant="outline"
                  className="h-20 flex flex-col items-center justify-center space-y-2 border-2 border-dashed hover:border-primary hover:bg-primary/5"
                >
                  <Icon className="w-6 h-6 text-gray-400" />
                  <span className="text-sm text-gray-600">{action.label}</span>
                </Button>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
