import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Layout from "@/components/Layout";
import Dashboard from "@/components/Dashboard";
import OrdersPage from "@/components/OrdersPage";
import InventoryPage from "@/components/InventoryPage";
import RoutesPage from "@/components/RoutesPage";
import ShipmentsPage from "@/components/ShipmentsPage";
import CostsPage from "@/components/CostsPage";
import WarehousePage from "@/components/WarehousePage";
import InvoicesPage from "@/components/InvoicesPage";
import AnalyticsPage from "@/components/AnalyticsPage";
import NotificationsPage from "@/components/NotificationsPage";
import TrackingPage from "@/components/TrackingPage";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/orders" component={OrdersPage} />
        <Route path="/inventory" component={InventoryPage} />
        <Route path="/routes" component={RoutesPage} />
        <Route path="/shipments" component={ShipmentsPage} />
        <Route path="/tracking" component={TrackingPage} />
        <Route path="/analytics" component={AnalyticsPage} />
        <Route path="/notifications" component={NotificationsPage} />
        <Route path="/costs" component={CostsPage} />
        <Route path="/warehouse" component={WarehousePage} />
        <Route path="/invoices" component={InvoicesPage} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
