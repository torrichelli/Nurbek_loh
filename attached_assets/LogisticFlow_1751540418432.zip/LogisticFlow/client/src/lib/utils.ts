import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export const formatCurrency = (amount: string | number) => {
  const num = typeof amount === 'string' ? parseFloat(amount) : amount;
  return new Intl.NumberFormat('ru-RU', {
    style: 'currency',
    currency: 'RUB',
  }).format(num);
};

export const formatDate = (date: Date | string) => {
  const d = new Date(date);
  return new Intl.DateTimeFormat('ru-RU', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(d);
};

export const getStatusColor = (status: string) => {
  const statusColors: Record<string, string> = {
    pending: 'bg-yellow-100 text-yellow-800',
    processing: 'bg-blue-100 text-blue-800',
    in_transit: 'bg-purple-100 text-purple-800',
    delivered: 'bg-green-100 text-green-800',
    cancelled: 'bg-red-100 text-red-800',
    active: 'bg-green-100 text-green-800',
    planned: 'bg-blue-100 text-blue-800',
    completed: 'bg-gray-100 text-gray-800',
    picked_up: 'bg-orange-100 text-orange-800',
    out_for_delivery: 'bg-indigo-100 text-indigo-800',
    draft: 'bg-gray-100 text-gray-800',
    sent: 'bg-blue-100 text-blue-800',
    paid: 'bg-green-100 text-green-800',
    overdue: 'bg-red-100 text-red-800',
  };
  return statusColors[status] || 'bg-gray-100 text-gray-800';
};

export const getStatusText = (status: string) => {
  const statusTexts: Record<string, string> = {
    pending: 'Ожидает',
    processing: 'В обработке',
    in_transit: 'В пути',
    delivered: 'Доставлен',
    cancelled: 'Отменен',
    active: 'Активен',
    planned: 'Планируется',
    completed: 'Завершен',
    picked_up: 'Забран',
    out_for_delivery: 'Доставляется',
    draft: 'Черновик',
    sent: 'Отправлен',
    paid: 'Оплачен',
    overdue: 'Просрочен',
  };
  return statusTexts[status] || status;
};
