import {
  orders,
  inventory,
  routes,
  shipments,
  warehouseOperations,
  invoices,
  type Order,
  type InsertOrder,
  type InventoryItem,
  type InsertInventoryItem,
  type Route,
  type InsertRoute,
  type Shipment,
  type InsertShipment,
  type WarehouseOperation,
  type InsertWarehouseOperation,
  type Invoice,
  type InsertInvoice,
} from "@shared/schema";

export interface IStorage {
  // Orders
  getOrders(): Promise<Order[]>;
  getOrder(id: number): Promise<Order | undefined>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrder(id: number, order: Partial<InsertOrder>): Promise<Order | undefined>;
  deleteOrder(id: number): Promise<boolean>;

  // Inventory
  getInventoryItems(): Promise<InventoryItem[]>;
  getInventoryItem(id: number): Promise<InventoryItem | undefined>;
  createInventoryItem(item: InsertInventoryItem): Promise<InventoryItem>;
  updateInventoryItem(id: number, item: Partial<InsertInventoryItem>): Promise<InventoryItem | undefined>;
  deleteInventoryItem(id: number): Promise<boolean>;
  getLowStockItems(): Promise<InventoryItem[]>;

  // Routes
  getRoutes(): Promise<Route[]>;
  getRoute(id: number): Promise<Route | undefined>;
  createRoute(route: InsertRoute): Promise<Route>;
  updateRoute(id: number, route: Partial<InsertRoute>): Promise<Route | undefined>;
  deleteRoute(id: number): Promise<boolean>;

  // Shipments
  getShipments(): Promise<Shipment[]>;
  getShipment(id: number): Promise<Shipment | undefined>;
  createShipment(shipment: InsertShipment): Promise<Shipment>;
  updateShipment(id: number, shipment: Partial<InsertShipment>): Promise<Shipment | undefined>;
  deleteShipment(id: number): Promise<boolean>;

  // Warehouse Operations
  getWarehouseOperations(): Promise<WarehouseOperation[]>;
  createWarehouseOperation(operation: InsertWarehouseOperation): Promise<WarehouseOperation>;

  // Invoices
  getInvoices(): Promise<Invoice[]>;
  getInvoice(id: number): Promise<Invoice | undefined>;
  createInvoice(invoice: InsertInvoice): Promise<Invoice>;
  updateInvoice(id: number, invoice: Partial<InsertInvoice>): Promise<Invoice | undefined>;
  deleteInvoice(id: number): Promise<boolean>;

  // Analytics
  getDashboardMetrics(): Promise<{
    activeOrders: number;
    inTransit: number;
    deliveredToday: number;
    issues: number;
    activeOrdersChange: string;
    inTransitChange: string;
    deliveredChange: string;
    issuesChange: string;
  }>;
}

export class MemStorage implements IStorage {
  private orders: Map<number, Order> = new Map();
  private inventory: Map<number, InventoryItem> = new Map();
  private routes: Map<number, Route> = new Map();
  private shipments: Map<number, Shipment> = new Map();
  private warehouseOperations: Map<number, WarehouseOperation> = new Map();
  private invoices: Map<number, Invoice> = new Map();
  private currentOrderId = 1;
  private currentInventoryId = 1;
  private currentRouteId = 1;
  private currentShipmentId = 1;
  private currentWarehouseOpId = 1;
  private currentInvoiceId = 1;

  constructor() {
    this.initializeData();
  }

  private initializeData() {
    // Initialize with some sample inventory items
    const sampleItems: InsertInventoryItem[] = [
      {
        itemCode: "A123",
        itemName: "Товар A123",
        description: "Описание товара A123",
        quantity: 5,
        minQuantity: 10,
        price: "100.00",
        unit: "шт",
        category: "Категория A",
        location: "Склад-1-А",
      },
      {
        itemCode: "B456",
        itemName: "Товар B456",
        description: "Описание товара B456",
        quantity: 15,
        minQuantity: 20,
        price: "250.00",
        unit: "шт",
        category: "Категория B",
        location: "Склад-1-Б",
      },
      {
        itemCode: "C789",
        itemName: "Товар C789",
        description: "Описание товара C789",
        quantity: 0,
        minQuantity: 5,
        price: "500.00",
        unit: "шт",
        category: "Категория C",
        location: "Склад-2-А",
      },
    ];

    sampleItems.forEach(item => {
      this.createInventoryItemSync(item);
    });
  }

  private createInventoryItemSync(item: InsertInventoryItem): InventoryItem {
    const id = this.currentInventoryId++;
    const newItem: InventoryItem = {
      id,
      itemCode: item.itemCode,
      itemName: item.itemName,
      description: item.description || null,
      quantity: item.quantity || 0,
      minQuantity: item.minQuantity || 10,
      price: item.price,
      unit: item.unit || "шт",
      category: item.category || null,
      location: item.location || null,
      updatedAt: new Date(),
    };
    this.inventory.set(id, newItem);
    return newItem;
  }

  // Orders
  async getOrders(): Promise<Order[]> {
    return Array.from(this.orders.values()).sort((a, b) => b.id - a.id);
  }

  async getOrder(id: number): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const id = this.currentOrderId++;
    const order: Order = {
      id,
      orderNumber: insertOrder.orderNumber,
      customer: insertOrder.customer,
      customerEmail: insertOrder.customerEmail || null,
      customerPhone: insertOrder.customerPhone || null,
      status: insertOrder.status,
      amount: insertOrder.amount,
      items: insertOrder.items,
      deliveryAddress: insertOrder.deliveryAddress,
      notes: insertOrder.notes || null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.orders.set(id, order);
    return order;
  }

  async updateOrder(id: number, updateData: Partial<InsertOrder>): Promise<Order | undefined> {
    const order = this.orders.get(id);
    if (!order) return undefined;

    const updatedOrder: Order = {
      ...order,
      ...updateData,
      updatedAt: new Date(),
    };
    this.orders.set(id, updatedOrder);
    return updatedOrder;
  }

  async deleteOrder(id: number): Promise<boolean> {
    return this.orders.delete(id);
  }

  // Inventory
  async getInventoryItems(): Promise<InventoryItem[]> {
    return Array.from(this.inventory.values()).sort((a, b) => a.itemName.localeCompare(b.itemName));
  }

  async getInventoryItem(id: number): Promise<InventoryItem | undefined> {
    return this.inventory.get(id);
  }

  async createInventoryItem(insertItem: InsertInventoryItem): Promise<InventoryItem> {
    return this.createInventoryItemSync(insertItem);
  }

  async updateInventoryItem(id: number, updateData: Partial<InsertInventoryItem>): Promise<InventoryItem | undefined> {
    const item = this.inventory.get(id);
    if (!item) return undefined;

    const updatedItem: InventoryItem = {
      ...item,
      ...updateData,
      updatedAt: new Date(),
    };
    this.inventory.set(id, updatedItem);
    return updatedItem;
  }

  async deleteInventoryItem(id: number): Promise<boolean> {
    return this.inventory.delete(id);
  }

  async getLowStockItems(): Promise<InventoryItem[]> {
    return Array.from(this.inventory.values()).filter(item => item.quantity <= item.minQuantity);
  }

  // Routes
  async getRoutes(): Promise<Route[]> {
    return Array.from(this.routes.values()).sort((a, b) => b.id - a.id);
  }

  async getRoute(id: number): Promise<Route | undefined> {
    return this.routes.get(id);
  }

  async createRoute(insertRoute: InsertRoute): Promise<Route> {
    const id = this.currentRouteId++;
    const route: Route = {
      id,
      status: insertRoute.status,
      createdAt: new Date(),
      routeName: insertRoute.routeName,
      driverName: insertRoute.driverName,
      vehicleNumber: insertRoute.vehicleNumber,
      orderIds: insertRoute.orderIds,
      distance: insertRoute.distance || null,
      estimatedTime: insertRoute.estimatedTime || null,
      cost: insertRoute.cost || null,
      startDate: insertRoute.startDate || null,
      endDate: insertRoute.endDate || null,
    };
    this.routes.set(id, route);
    return route;
  }

  async updateRoute(id: number, updateData: Partial<InsertRoute>): Promise<Route | undefined> {
    const route = this.routes.get(id);
    if (!route) return undefined;

    const updatedRoute: Route = {
      ...route,
      ...updateData,
    };
    this.routes.set(id, updatedRoute);
    return updatedRoute;
  }

  async deleteRoute(id: number): Promise<boolean> {
    return this.routes.delete(id);
  }

  // Shipments
  async getShipments(): Promise<Shipment[]> {
    return Array.from(this.shipments.values()).sort((a, b) => b.id - a.id);
  }

  async getShipment(id: number): Promise<Shipment | undefined> {
    return this.shipments.get(id);
  }

  async createShipment(insertShipment: InsertShipment): Promise<Shipment> {
    const id = this.currentShipmentId++;
    const shipment: Shipment = {
      id,
      status: insertShipment.status,
      notes: insertShipment.notes || null,
      createdAt: new Date(),
      updatedAt: new Date(),
      trackingNumber: insertShipment.trackingNumber,
      orderId: insertShipment.orderId,
      routeId: insertShipment.routeId || null,
      currentLocation: insertShipment.currentLocation || null,
      estimatedDelivery: insertShipment.estimatedDelivery || null,
      actualDelivery: insertShipment.actualDelivery || null,
    };
    this.shipments.set(id, shipment);
    return shipment;
  }

  async updateShipment(id: number, updateData: Partial<InsertShipment>): Promise<Shipment | undefined> {
    const shipment = this.shipments.get(id);
    if (!shipment) return undefined;

    const updatedShipment: Shipment = {
      ...shipment,
      ...updateData,
      updatedAt: new Date(),
    };
    this.shipments.set(id, updatedShipment);
    return updatedShipment;
  }

  async deleteShipment(id: number): Promise<boolean> {
    return this.shipments.delete(id);
  }

  // Warehouse Operations
  async getWarehouseOperations(): Promise<WarehouseOperation[]> {
    return Array.from(this.warehouseOperations.values()).sort((a, b) => b.id - a.id);
  }

  async createWarehouseOperation(insertOperation: InsertWarehouseOperation): Promise<WarehouseOperation> {
    const id = this.currentWarehouseOpId++;
    const operation: WarehouseOperation = {
      id,
      createdAt: new Date(),
      type: insertOperation.type,
      quantity: insertOperation.quantity,
      itemId: insertOperation.itemId,
      reason: insertOperation.reason || null,
      operatorName: insertOperation.operatorName,
    };
    this.warehouseOperations.set(id, operation);
    return operation;
  }

  // Invoices
  async getInvoices(): Promise<Invoice[]> {
    return Array.from(this.invoices.values()).sort((a, b) => b.id - a.id);
  }

  async getInvoice(id: number): Promise<Invoice | undefined> {
    return this.invoices.get(id);
  }

  async createInvoice(insertInvoice: InsertInvoice): Promise<Invoice> {
    const id = this.currentInvoiceId++;
    const invoice: Invoice = {
      id,
      status: insertInvoice.status,
      items: insertInvoice.items,
      createdAt: new Date(),
      orderId: insertInvoice.orderId || null,
      invoiceNumber: insertInvoice.invoiceNumber,
      customerName: insertInvoice.customerName,
      customerAddress: insertInvoice.customerAddress,
      subtotal: insertInvoice.subtotal,
      tax: insertInvoice.tax || null,
      total: insertInvoice.total,
      dueDate: insertInvoice.dueDate || null,
    };
    this.invoices.set(id, invoice);
    return invoice;
  }

  async updateInvoice(id: number, updateData: Partial<InsertInvoice>): Promise<Invoice | undefined> {
    const invoice = this.invoices.get(id);
    if (!invoice) return undefined;

    const updatedInvoice: Invoice = {
      ...invoice,
      ...updateData,
    };
    this.invoices.set(id, updatedInvoice);
    return updatedInvoice;
  }

  async deleteInvoice(id: number): Promise<boolean> {
    return this.invoices.delete(id);
  }

  // Analytics
  async getDashboardMetrics() {
    const orders = Array.from(this.orders.values());
    const shipments = Array.from(this.shipments.values());
    
    const activeOrders = orders.filter(o => o.status === 'processing' || o.status === 'pending').length;
    const inTransit = shipments.filter(s => s.status === 'in_transit' || s.status === 'out_for_delivery').length;
    
    // For delivered today, check shipments delivered today
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const deliveredToday = shipments.filter(s => 
      s.status === 'delivered' && 
      s.actualDelivery && 
      new Date(s.actualDelivery) >= today
    ).length;
    
    // Issues could be delayed shipments or cancelled orders
    const issues = orders.filter(o => o.status === 'cancelled').length + 
                  shipments.filter(s => s.status === 'pending' && s.estimatedDelivery && new Date(s.estimatedDelivery) < new Date()).length;

    return {
      activeOrders,
      inTransit,
      deliveredToday,
      issues,
      activeOrdersChange: '+12%',
      inTransitChange: '+5%',
      deliveredChange: '+8%',
      issuesChange: '-3%',
    };
  }
}

export const storage = new MemStorage();
